function SUtracehead=SU_getTraceHeaders(filein)
SUtracehead=TraceHeader(filein,'hdroffset','0');
end
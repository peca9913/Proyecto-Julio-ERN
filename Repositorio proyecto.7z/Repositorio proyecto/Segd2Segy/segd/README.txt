This code has been tested on exactly one shot gather disk file, which contained the segd file headers and trace data in a single file.

-Kevin Hall, September 28, 2011


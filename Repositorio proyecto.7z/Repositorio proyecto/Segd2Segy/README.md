# Segd2Segy
SEGD to SEGY Converter with MATLAB

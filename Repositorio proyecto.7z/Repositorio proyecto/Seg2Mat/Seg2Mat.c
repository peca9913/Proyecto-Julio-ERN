#define MATOUTPUT
/*
	FROM THE PUBLISHED VERSION IN GEOPHYSICS, SEPT '90
	Original Header:
	NAME:            SEG2SEGY.C
	VERSION:         V1.0
	CREATION DATE:   6/15/90
	AUTHOR:          Brett Bennett
	PURPOSE:         Conversion of the SEG2-PC standard data set 
		 to SEG-Y 32-BIT format.
	LIMITATIONS:     In this implementation of the conversion only
	the data generated in the IBM byte ordering method can be
	converted.  i.e.  byte ordering must be LSB-MSB Data generated
	by a 68000 processor, for instance, will not convert.  A flag
	is however in the code for future addition of this capability.
	The SEG-Y file also differs slightly from Barry et al standard.
	Word 88 is defined as "last-trace-flag" rather than "Geophone
	group number of last trace within original file."  This
	simplification greatly reduces the amount of code needed for
	conversion.  Header word 92 is defined here as the
	Shot-Sequence-Number.  This is used to assign each trace group a
	unique number.

	EXTENSIVE REWRITE/HACK AND PORT: 11/95 
	AUTHOR: Ian Kay.  
	-Added code to handle running on big-endian machines.
	-Replaced all non-unix portable code and library calls.
	-Typed all the ints so they are the right types
	    (on DOS int=short, on Unix int=long)
	-removed calls to "ieeeibm" since workstations are ieee floating point
	    format as well.
	-partial addition of structures to handle the keywords and headers.
	but I eventually gave up.

	$Id: seg2segy.c,v 1.2 2003/02/06 19:05:45 pm Exp $

	Changes:
	Feb 96.  Trace header was not being written out with swap on bytes above
	89 although info is stored in 92,93,94.  Error in original, fixed.

	Oct 97.  Changed the input to command line, inspired by the seg2segy
	version in CWP/SU package.
	
	Jan 98.  
	fixed malloc problem; not enough space was malloced to hold the 
	string defpath. 
	freed the malloced space when finished. 
	closed the segykeyword file when finished.
	changed curf and lastf to int from short; this should allow digits
	in the file name prefix (but what will happen in DOS?).

	Sep 98.
	Ok.  So no one can figure out the segykeyword file mechanism, 
	so I've changed it.  Now, if the environment variable SEGKEYPATH
	is set , then that file is used for the segykeywords. If that
	isn't set then a system default is used /usr/local/lib/segykeyword
	or "segykeyw.ord" in the local directory in DOS.  Finally, neither
	of those exist, then the default values are built in.  

	NOTE that this means that you can do away with the segykeyword
	file altogether!

        16 Jan, 2011  Stewart A. Levin (Stanford Exploration Project)
        Cribbed seg2segy.c from SU to generate SEPlib compatible data

        15 Jan, 2011  Stewart A. Levin
        Reparameterized with 16 and 32 bit typedefs so that it works
        on 64-bit architectures.
        Rewrote SEG-D 20 bit conversion so that it actually honors the
        format!
        Handle more Trace Descriptor Block strings and use coordinate and
        elevation/depth scalars for better precision.
        Flag as SEG-Y Rev 1.

	$Log: seg2segy.c,v $
	Revision 1.2  2003/02/06 19:05:45  pm
	fixed sawtooth on 20bit packed data conversion case 3
	
	Revision 1.1  2003/02/06 18:44:59  pm
	working on 3rdparty seismic unix
	
	Revision 1.2  2002/11/12 16:01:43  john
	type changed on i,j,k to in
	t

	Revision 1.1  2001/04/12 17:55:11  john
	Initial revision

	Revision 1.7  1998/10/08 20:17:15  kay
	A little more cleanup...^[

	Revision 1.6  1998/10/07 18:54:40  kay
	Built in the defaults for the segykeyword file.  This file is no longer
	needed.

	Revision 1.5  1998/01/07 13:36:15  kay
	added new changes and a Log for the future

 */

#include <stdlib.h>
#include <stdio.h>
#include <stdint.h>
#include <sys/types.h>
#include <math.h>
#include <string.h>
#include <ctype.h>
#ifndef __MSDOS__   
#include <unistd.h>
#define MAXSAMP 65535
#define MAXTRACES 65535
#else
#include <io.h>
typedef short uint16_t;
typedef long uint32_t;
#define MAXSAMP 4096
#define MAXTRACES 512
#endif

#ifndef NULL
#define NULL    ((void *)0)
#endif 

#define STRINGWIDTH 112
#define MAXKEYWORDS 111
#define MAXPARMS 10

/* global data... */
static uint16_t segyreelheader[1800];
static int totalkeys;
static char string1[200];
static uint16_t outhead[120];


typedef struct _SegyKeyTable
	{
	char segykeyword[STRINGWIDTH];
	int segyfunction;
	int segyheader;
	double segyparms[MAXPARMS];
	} SegyKeyTable;


static void
swapshort (uint16_t *si)
{
	uint16_t temp, temp1, temp2;
	temp = *si;
        temp1 = temp & 0x00ff;
        temp2 = temp & 0xff00;
	temp = (temp1<<8) | (temp2>>8);
        *si = temp;
}

static void
swaplong (uint32_t *li)
{
	uint32_t temp, temp1, temp2;
	temp = *li;
	temp1 = temp & 0x0000ffff;
	temp2 = temp & 0xffff0000;
	temp = (temp1<<16) | (temp2>>16);
	temp1 = temp & 0x00ff00ff;
        temp2 = temp & 0xff00ff00;
	temp = (temp1<<8) | (temp2>>8);
	*li = temp;
}

static void
swapdouble (double *d)
{
        union {
           uint32_t oval[2];
           double dval;
        } tmp;
        uint32_t ut;

        tmp.dval = *d;
        swaplong(tmp.oval+0);
        swaplong(tmp.oval+1);
        ut = tmp.oval[0];
        tmp.oval[0] = tmp.oval[1];
        tmp.oval[1] = ut;
        *d = tmp.dval;
}

static void
float_to_ibm(uint32_t from[], uint32_t to[], uint32_t n)
{
	register uint32_t fconv, fmant, ii, t;

	for (ii=0;ii<n;++ii) {
	fconv = from[ii];
	if (fconv) {
	fmant = (0x007fffff & fconv) | 0x00800000;
	t = (long) ((0x7f800000 & fconv) >> 23) - 126;
	while (t & 0x3) { ++t; fmant >>= 1; }
	fconv = (0x80000000 & fconv) | (((t>>2) + 64) << 24) | fmant; 
	} 
	to[ii] = fconv; 
	} 
	return; 
}

static char *
strrev (char *s)
{
	char *tmpstr;
	int i, len;
	tmpstr = (char *) malloc (sizeof (char) * strlen (s));
	len = 0;
	while (s[len] != '\0')
	 len++;
	for (i = 0; i < len; i++) {
	tmpstr[i] = s[len - 1 - i];
	  tmpstr[i + 1] = '\0';
	}
	tmpstr[++i] = '\0';
	strcpy (s, tmpstr);
	free (tmpstr);
	tmpstr = (char *) NULL;
	return s;
}


static void
parseSegyKeys(FILE *keyfptr, SegyKeyTable *keywords)
{
	int i, j;
	char input[STRINGWIDTH], inputbuf[STRINGWIDTH];
	char *token;
	i = 0;
	while (fgets (input, STRINGWIDTH, keyfptr)) {
	j = 0;
	if ( strlen(input) > (size_t)STRINGWIDTH) {
	fprintf (stderr, "String too long!\n (line:%d)\n", __LINE__);
	exit (-12);
	}
	/*  
	 * if left most character = "*" then 
	 * this line is a comment and should be ignored. 
	 */
	if (input[0] == '*' || input[0] == '\n')  
	continue;

	strcpy (inputbuf, input);  /* make a working copy of input */
	token = strtok (inputbuf, " ");  /* search out space. */

	/* copy keyword into array */
	strncpy (keywords[i].segykeyword, token, 1 + strlen (token));

	/* get function value. */
	token = strtok (NULL, " ");
	keywords[i].segyfunction = atoi (token);  /* convert to value. */
	token = strtok (NULL, " ");

	/* get segy header pointer */
	keywords[i].segyheader = atoi (token);

	/* now start getting any parameters on the line. */
	token = strtok (NULL, " ");
	j = 0;
	while (token != NULL) {
	/* get next token and start putting them in their array location */
	keywords[i].segyparms[j] = atof (token);
	token = strtok (NULL, " ");
	j++;
	if (j > MAXPARMS) {
	printf ("Too many parameters in %s keyword\n", keywords[i].segykeyword);
	printf ("No more than %d allowed per function\n", j - 1);
	exit (-13);
	}
	}      /* end parameter extraction while loop */
	i++;      /* inc counter to keyword number */
	}        /* end keyword string while loop */
	totalkeys = i;
	
}        /* end parseSegyKeys() */

static void
loadSegyKeyTableDefaults(SegyKeyTable * keywords)
{
const char *defaults[] = {
"ACQUISITION_DATE 6 81 ",
"ACQUISITION_SECOND_FRACTION 1 54 1000 ",
"ACQUISITION_TIME 7 84 ",
"ALIAS_FILTER 5 0 1 71 72 ",
"CDP_NUMBER 5 1 1 12 ",
"CDP_TRACE 5 1 1 14 ",
"CHANNEL_NUMBER 5 1 1 8 ",
"CLIENT 3 1 ", 
"COMPANY 3 2 ",
"DATUM 5 2 1 28 ",
"DELAY 1 55 1000 ",
"END_OF_GROUP 1 88 1 ",
"FIXED_GAIN 1 61 1 ",
"FIXED_GAIN 1 62 1 ",
"HIGH_CUT_FILTER 5 0 1 76 78 ",
"INSTRUMENT 3 4 ",
"JOB_ID 3 7 ",
"LINE_ID 3 3 ",
"LOW_CUT_FILTER 5 0 1 75 77 ",
"MODULE_SERIAL_NUM 5 1 1 99 ",
"NOTCH_FREQUENCY 5 0 1 73 ",
"OBSERVER 3 5 ",
"RAW_RECORD 3 8 ",
"RECEIVER_LOCATION 5 2 1 42 44 22 ",
"RECEIVER_STATION_NUMBER 5 1 1 98 ", /* put in "3D crossline" */
"RECEIVER 8 15 ", /* set SEG-Y Rev 1 trace type from this if possible */
"SAMPLE_INTERVAL 1 59 1000000 ",
"SENSOR_CALIBRATION_DB 5 2 1 100 ",
"SENSOR_ORIENTATION 5 2 101 101 102 103 ",
"SOURCE_LOCATION 5 2 1 38 40 26 ",
"SHOT_SEQUENCE_NUMBER 5 1 1 6 ",
"SOURCE_STATION_NUMBER 5 1 1 96 10 ", /* put in "3D inline" and source point */
"STACK 1 16 1 ",
"STATIC_CORRECTIONS 5 0 1 50 51 52 ",
"TRACE_SORT 2 1615 ",
"TRACE_TYPE 4 15 ",
"UNITS 3 6 ",
"AMPLITUDE_RECOVERY 0 0 ",
"BAND_REJECT_FILTER 0 0 ",
"DESCALING_FACTOR 0 0 ",
"DIGITAL_BAND_REJECT_FILTER 0 0 ",
"DIGITAL_HIGH_CUT_FILTER 0 0 ",
"DIGITAL_LOW_CUT_FILTER 0 0 ",
"GENERAL_CONSTANT 0 0 ",
"NOTE 0 0  ",
"POLARITY 0 0 ",
"PROCESSING_DATE 3 9 ",
"PROCESSING_TIME 3 10 ",
"RECEIVER_GEOMETRY 0 0 ",
"RECEIVER_SPECS 0 0 ",
"RECORD_INDEX 0 0 ",
"SKEW 0 0  ",
"SOURCE 0 0 ",
"SOURCE_GEOMETRY 0 0 ",
"SOURCE_LINE_ID 0 0 ",
NULL};
	const char **defaultsptr=defaults;

	char tmpfilename[L_tmpnam];
	FILE *tmpfileptr;

	tmpnam(tmpfilename);
	tmpfileptr=fopen(tmpfilename, "w");
	/*fwrite(defaults, sizeof(char), strlen(defaults), tmpfileptr); */

	while(*defaultsptr) fprintf(tmpfileptr,"%s\n", *defaultsptr++);

	tmpfileptr=freopen(tmpfilename,"r",tmpfileptr);

	parseSegyKeys(tmpfileptr, keywords);
	fclose(tmpfileptr);
	remove(tmpfilename);
	
}        /* end loadSegyKeyTableDefaults() */


/*-----------------------------------------------------------------------
	READSEGYKEYS
	This routine reads in the valid keywords in file SEGKEYW.ORD 
	and stores the results in global arrays
----------------------------------------------------------------------*/
void
readSegyKeys (SegyKeyTable *keywords)
{
	char *envkeypath;
	char *syskeypath;
#ifdef __MSDOS__
	char defpath[] = "segykeyw.ord";
#else
	char defpath[] = "/usr/local/lib/segykeyword";
#endif

	FILE *keyfile;

	syskeypath = (char *) malloc ((strlen(defpath)+1) * sizeof(char));
	sprintf (syskeypath, "%s", defpath);
	envkeypath = getenv ("SEGKEYPATH");

	if (envkeypath != (char *) NULL)
	{
	if((keyfile=fopen(envkeypath,"rb")) != (FILE *)NULL)
	fprintf (stderr, "%s used for header word mapping.\n", envkeypath); 
	parseSegyKeys(keyfile, keywords);
	fclose (keyfile);
	} 
	else if ((keyfile = fopen (syskeypath, "rb")) != (FILE *)NULL)
	{
	fprintf (stderr, "Using header word mappings in %s\n",defpath);
	parseSegyKeys(keyfile, keywords);
	fclose (keyfile);
	} 
	else 
	{ 
	fprintf (stderr, "Using default header word mappings. \n");
	loadSegyKeyTableDefaults(keywords);
	}
	free(syskeypath);
	return;
}        /* end readsegyKeys() */



/*------------------------------------------------------------
 * KEYCHECK
 * This routine compares list of keywords with the global string 1 and inserts
 * values found in the input string into specified header locations (see
 * segykeyw.ord).  KEYCHECK checks EVERY keyword for a match.  Repeated 
 * keywords are valid.
 * GLOBALS USED:
 * totalkeys int
 *------------------------------------------------------------*/
void
keycheck (SegyKeyTable *keywords)
{
	int i;
	int matchfound;
	char string2[STRINGWIDTH];
	char *token;
        int16_t i16;
        int32_t i32;

	/* start a loop for total keys and compare the input with the list */
	/* make a copy of string1. strtok destroys it's input during token search*/
	/* therefore need to keep a copy for each keyword checked */
	strcpy (string2, string1);

	/* clear the match found flag */
	matchfound = 0;
	for (i = 0; i < totalkeys; i++) 
	{
	/* 
	 * restore string1.  It will have been destroyed if an 
	 * earlier match has occured. 
	 */
	strcpy (string1, string2);  

	if (0 == strncmp (string1, keywords[i].segykeyword, 
		strlen (keywords[i].segykeyword) ) )
          if(' ' == string1[strlen(keywords[i].segykeyword)])
	{
	/* have found a match! Set the matchfound flag */
	matchfound = 1;
	/* look up the function and implement it. */
	switch (keywords[i].segyfunction)
	{
	case 0:
		break;    /* null case nothing to do */
	case 1:
	{
	/* function 1 keywords have a single parameter 
	 * in the input;  assumed to be a number.  */
	/* find the parameter. */
	/* find first token which will be a keyword */
	token = strtok (string1, " ");  
	/* should be a number. */
	token = strtok (NULL, " ");  	
	/* parameter found. pointed to by token. */
	/* function 1 calls for the value on the input line to be mulitplied */
	/* by segykeyword parm 1. and then inserted into header. */
        i16 = (int16_t) rint(atof (token) * keywords[i].segyparms[0]);
        outhead[keywords[i].segyheader - 1] = *((uint16_t *) (&i16));
	break;
	}
	case 2:
	{
	/* function 2 is a special function.  It has to deal with the special 
	 * case of trace sorting. In this case the parameter on the input 
	 * line is not a number  but a char string.  
	 * Notice that spaces in the keywords (i.e. AS ACQUIRED) cause 
	 * the parsing to fail.  Words must be 'spaceless' */
	token = strtok (string1, " ");  	/* pointing to keyword. */
	token = strtok (NULL, " ");  	/* token points to input char. */
	if (0 == strcmp ("AS_ACQUIRED", token))
		segyreelheader[keywords[i].segyheader - 1] = 1;
	else if (0 == strcmp ("CDP_GATHER", token))
		segyreelheader[keywords[i].segyheader - 1] = 2;
	else if (0 == strcmp ("CDP_STACK", token))
		segyreelheader[keywords[i].segyheader - 1] = 4;
	else if (0 == strcmp ("COMMON_OFFSET", token))
		segyreelheader[keywords[i].segyheader - 1] = 3;
	else if (0 == strcmp ("COMMON_RECEIVER", token))
		segyreelheader[keywords[i].segyheader - 1] = 1;
	else if (0 == strcmp ("COMMON_SOURCE", token))
		segyreelheader[keywords[i].segyheader - 1] = 1;
	else if (0 == strcmp ("METERS",token))
		segyreelheader[keywords[i].segyheader -1] = 1;
	else if (0 == strcmp ("FEET",token))
		segyreelheader[keywords[i].segyheader -1] = 2;

	break;
	}      /* end case 2 */
	case 3:
	{
	/* 
	 * this case requires the text string found on the input
	 * line to be copied to the SEGY-REEL header at the line
	 * indicated in the segyheader index. to compute this
	 * location it is (line#-1)*80
	 */
	strncpy ((char *) &segyreelheader[80 * (keywords[i].segyheader - 1)], 
		string1, 80);
	break;
	}      /* end case 3 */
	case 4:
	{
	/* this case, like 2, calls for special string parsing. */
	/* for TRACE_TYPE, see code for allowable inputs. */
	/* pointing to keyword. */
	if(outhead[keywords[i].segyheader - 1] == 0) {
	   token = strtok (string1, " "); 
	   /* assume its seismic */
           outhead[keywords[i].segyheader - 1] = 1;  
	   /* token points to input char. */
	   token = strtok (NULL, " "); 
	   if (0 == strcmp ("SEISMIC_DATA", token))
		outhead[keywords[i].segyheader - 1] = 1;
	   else if (0 == strcmp ("DEAD", token))
		outhead[keywords[i].segyheader - 1] = 2;
	   else if (0 == strcmp ("TEST_DATA", token))
		outhead[keywords[i].segyheader - 1] = 3;
	   else if (0 == strcmp ("UPHOLE", token))
		outhead[keywords[i].segyheader - 1] = 5;
	   /* RADAR_DATA not defined in SEG-Y assume it to be normal seismic */
	   else if (0 == strcmp ("RADAR_DATA", token))
		outhead[keywords[i].segyheader - 1] = 1;
        }
	break;
	}      /* end case 4 */
	case 5:
	{
	/* this case calls for the input data to be inserted into the 
	 * specified header location of parms 2-10. The normal 
	 * 'header' location indicates the type of data, 0=int, 
	 * 1=long int, 2=floating point. Parm 1 is the multiplier. */
	token = strtok (string1, " ");
	/* do the integer case first */
	if (keywords[i].segyheader == 0) {
		int paramcount = 1;
		int headindex;
		token = strtok (NULL, " ");    	/* token points to input char. */
		while (token != NULL && paramcount < 10) {
		headindex = keywords[i].segyparms[paramcount] - 1;
                i16 = (int16_t) rint(atof (token) * keywords[i].segyparms[0]);
		outhead[headindex] = *((uint16_t *) (&i16));
                paramcount++;
		token = strtok (NULL, " ");  /* token points next input char. */
		}
	}
		/* do the long integer case next */
	else if (keywords[i].segyheader == 1) {
		int paramcount = 1;
		int headindex;
		int32_t *outpoint;
		token = strtok (NULL, " ");    /* token points to input char. */
		while (token != NULL && paramcount < 10) {
		/* set outpoint to beginning of WORD of interest */
		/* need to subtract 2 from the location value. */
		headindex = keywords[i].segyparms[paramcount] - 2;
		outpoint = (int32_t *) (&outhead[headindex]);
		/* outpoint now points to the area of interest and is 
		 * typed correctly. Compute the value, cast it and send it in. */
		outpoint[0] = (int32_t) rint(atof (token) * keywords[i].segyparms[0]);
		paramcount++;
		token = strtok (NULL, " ");  /* token points next input char. */
		}
	}
	/* finally do floating point case */
	else if (keywords[i].segyheader == 2) {
		int paramcount = 1;
		int headindex;
		float *outpoint;
		token = strtok (NULL, " ");    /* token points to input char. */
		while ((token != NULL) && (paramcount < 10))
		{
		/* set outpoint to point to beginning of WORD of interest */
		/* need to subtract 2 from the location value. */
		headindex = keywords[i].segyparms[paramcount] - 2;
		outpoint = (float *) (&outhead[headindex]);
		/* outpoint now points to the area of interest and is typed 
		 * correctly. Compute the value, cast it and put it in 
		 * outhead (using outpoint). */
		outpoint[0] = (float) (atof (token) * keywords[i].segyparms[0]);
		paramcount++;
		/*   ieee2ibm(outpoint,0); *//* convert to ibm format if necessary */
		token = strtok (NULL, " ");  /* token points next input char. */
		}
	}
	break;
	}      /* end case 5 */
	case 6: 
	{
	uint16_t day, year;
	token=strtok(string1," "); 
	token=strtok(NULL,"/-"); 
	day=atoi(token);
	token=strtok(NULL,"/-");
	if (0==strcmp("FEB",token) || 0==strcmp("02",token)) day+=31;
	else if(0 == strcmp("MAR",token) || 0== strcmp("03",token)) day+=59;
	else if(0 == strcmp("APR",token) || 0== strcmp("04",token)) day+=90;
	else if(0 == strcmp("MAY",token) || 0== strcmp("05",token)) day+=120;
	else if(0 == strcmp("JUN",token) || 0== strcmp("06",token)) day+=151;
	else if(0 == strcmp("JUL",token) || 0== strcmp("07",token)) day+=181;
	else if(0 == strcmp("AUG",token) || 0== strcmp("08",token)) day+=212;
	else if(0 == strcmp("SEP",token) || 0== strcmp("09",token)) day+=243;
	else if(0 == strcmp("OCT",token) || 0== strcmp("10",token)) day+=273;
	else if(0 == strcmp("NOV",token) || 0== strcmp("11",token)) day+=304;
	else if(0 == strcmp("DEC",token) || 0== strcmp("12",token)) day+=334;
		token=strtok(NULL," ");/* token points to input char. */
	year=atoi(token);
	if(!year%4 && day>59) day+=1;  /* Yikes.  This may break! */
	outhead[keywords[i].segyheader - 2] = year;
	outhead[keywords[i].segyheader - 1] = day;
	break; 
	} 
	case 7: 
	{
	uint16_t hour, minute, second;
	token=strtok(string1," "); 
	token=strtok(NULL,":"); 
	hour=atoi(token);
	token=strtok(NULL,":");
        minute=atoi(token);
        token=strtok(NULL," ");/* token points to input char. */
	second=atoi(token);
	outhead[keywords[i].segyheader - 3] = hour;
        outhead[keywords[i].segyheader - 2] = minute;
	outhead[keywords[i].segyheader - 1] = second;
	break; 
	} 
	case 8:
	{
	/* this case, like 4, calls for special string parsing. */
	/* for TRACE_TYPE, see code for allowable inputs. */
	/* pointing to keyword. */
	token = strtok (string1, " ");
	/* token points to input char. */
	token = strtok (NULL, " "); 
	if (0 == strcmp ("VERTICAL_GEOPHONE", token))
		outhead[keywords[i].segyheader - 1] = 12;
	else if (0 == strcmp ("SH_HORIZONTAL_GEOPHONE", token))
		outhead[keywords[i].segyheader - 1] = 13;
	else if (0 == strcmp ("SV_HORIZONTAL_GEOPHONE", token))
		outhead[keywords[i].segyheader - 1] = 14;
	else if (0 == strcmp ("RECEIVER_HORIZONTAL_INLINE_GEOPHONE", token))
		outhead[keywords[i].segyheader - 1] = 14;
	else if (0 == strcmp ("HORIZONTAL_INLINE_GEOPHONE", token))
		outhead[keywords[i].segyheader - 1] = 14;
	else if (0 == strcmp ("RECEIVER_HORIZONTAL_CROSSLINE_GEOPHONE", token))
		outhead[keywords[i].segyheader - 1] = 13;
	else if (0 == strcmp ("HORIZONTAL_CROSSLINE_GEOPHONE", token))
		outhead[keywords[i].segyheader - 1] = 13;
	else if (0 == strcmp ("RECEIVER_HORIZONTAL_OTHER_GEOPHONE", token))
		outhead[keywords[i].segyheader - 1] = 12;
	else if (0 == strcmp ("HORIZONTAL_OTHER_GEOPHONE", token))
		outhead[keywords[i].segyheader - 1] = 12;
	break;
	}      /* end case 8 */
	default:    /* case where function not found.. should never happen */
	{
	printf ("Function %d not defined.\n", keywords[i].segyfunction);
	break;
	}
	}            /* end switch */
	break;        /* don't go through rest of for() loop, go to next string */
	}              /* end if */
		      	/* loop through and see if it can be found again */
	}                /* end of i loop */
	if (!matchfound)      /* did a match occur */
	 	printf ("No match found for %s\n", string1);
}             /* end of keysegy */
 



int
main (int argc, char *argv[])
{

#define NFILECHAR 255
	char  prefix[NFILECHAR], seg2file[NFILECHAR],
	SEPhdrfile[NFILECHAR], suffix[NFILECHAR], str[NFILECHAR];
        char SEPhdrfile_at[NFILECHAR], SEPdatafile_at[NFILECHAR];
        char MATstructname[NFILECHAR], MATfile[NFILECHAR];
        char SEPdatafile[NFILECHAR];
	char digits[] = "1234567890";
        char *datapath = (char *) NULL;
        char *ctmp;
	char stringtermcount, stringterm1, stringterm2;
	char linetermcount, lineterm1, lineterm2;
	char reserved[19];
	unsigned char datatype;
        int32_t thdrvals[87];
        int i, j, k; 
        int icnt;
        int ntoconvert;
	int ssn = 0; /* SEP n3 counter */
	int reversed;  /* 1 if seg2 file is MSDOS little-endian byte ordered, 0 if not */
        int ImLittleEndian;  /* 1 if current machine is little-endian, 0 if not */
	union { uint32_t s; uint16_t c[2]; } etest;
        int curf, lastf;
	uint16_t blockid, revnum, pointerbytecount, numtrace, stringlength;
	short int first = 1;
	size_t l,ln;
        ssize_t l1;
	uint16_t blockleng, sl;
        uint32_t ul;
	uint32_t tracepointers[MAXTRACES];
        int32_t outbuf[MAXSAMP];
	uint32_t *outheadl;
	uint32_t numsamples, datalength;
	FILE *f1, *f2, *f2_at, *f3, *f3_at, *fm;
	SegyKeyTable keywords[MAXKEYWORDS];

        char MatFileHdr[128];
        char fieldNameBuf[32];
        char fileHdrLine[STRINGWIDTH];
        char thdrNameBuf[32];

        off_t start_of_seg2_structure;
        off_t start_of_file_header;
        off_t start_of_trace_data;
        off_t current_trace_header;
        off_t current_trace_data;
        off_t curr_mat_loc;

        float ftmp;
        double dtmp;

	double *dinbuf;
	float *finbuf;
	uint32_t *linbuf;
	uint16_t *iinbuf;
	unsigned char *cinbuf;

        dinbuf = (double *) calloc(MAXSAMP,sizeof(double));
        finbuf = (float *) dinbuf;
        linbuf = (uint32_t *) dinbuf;
        iinbuf = (uint16_t *) dinbuf;
        cinbuf = (unsigned char *) dinbuf;

        etest.s = 1;
        ImLittleEndian = (etest.c[0] != 0);

#ifdef MATOUTPUT
        memset(MatFileHdr,'\0',sizeof(MatFileHdr));
        strcpy(MatFileHdr,"MATLAB 5.0 MAT-file, XDR format, Created by Seg2Mat\n");
        MatFileHdr[124] = '\001';
        MatFileHdr[125] = '\000';
        MatFileHdr[126] = 'M';
        MatFileHdr[127] = 'I';
#endif

	outheadl = (uint32_t *) &outhead[0];
	for (i = 0; i < 1800; i++) segyreelheader[i] = 0;
	for (i = 0; i < 120; i++) outhead[i] = 0;
        outhead[34] = -100;
        outhead[35] = -100;

	if (argc < 3 || argc > 4) { 
	printf("Usage: %s first-seg2file number-of-files [shot-number]\n", argv[0]);
	exit(-1);
	}
        ntoconvert = atoi(argv[2]);
        datapath = getenv("DATAPATH");
	sprintf(seg2file,"%s", argv[1]);
	if (strchr(seg2file,'.')==NULL)
		strcat(seg2file, ".dat");
        ctmp = strrchr(seg2file,'/');
        if(ctmp == ((char *) NULL)) ctmp = seg2file-1;
        strcpy(MATstructname,++ctmp);
        ctmp = strrchr(MATstructname,'.');
        if(ctmp == ((char *) NULL)) { l = strlen(MATstructname);
        } else {
        l = (ctmp - MATstructname); /* exclude .whatever suffix */
        }
        MATstructname[l] = '\0';
        /* sanitize MATlab variable name */
        for(l1 = 0; l1 < l; ++l1) {
           if(l1 == 0 && !isalpha(MATstructname[l1])) MATstructname[l1]='Z';
           if(!isalnum(MATstructname[l1]) && MATstructname[l1] != '_') 
		MATstructname[l1] = '_';
        }
        ctmp = strrchr(seg2file,'.');
        l = ctmp - seg2file; /* exclude .whatever suffix */
	strncpy(SEPhdrfile, seg2file, l); 
	SEPhdrfile[l]='\0';
	strcpy(suffix,seg2file+l);
        l1 = 0;
        ctmp = strrchr(seg2file,'/');
        if(ctmp != ((char *) NULL)) l1 = ctmp - seg2file;
        if(ntoconvert > 1) {
	   l=l1+strcspn(SEPhdrfile+l1,digits);
	   if (l==strlen(SEPhdrfile) 
	      || strspn(SEPhdrfile+l,digits)!=strlen(SEPhdrfile+l)){ 
	      printf("file name seg2 %s invalid\n", seg2file);
              exit(-2);
           }
	   strncpy(prefix, SEPhdrfile, l); prefix[l]='\0';
	   curf=atoi(SEPhdrfile+l);
	   ln=strlen(SEPhdrfile+l);
	} else {
          strcpy(prefix, SEPhdrfile);
        }
        if(datapath != ((char *) NULL)) {
		strcpy(SEPdatafile,datapath);
		strcat(SEPdatafile,"/");
        } else {
		curf = 1;
                SEPdatafile[0] = '\0';
        }
        strcat(SEPdatafile, SEPhdrfile);
        strcpy(SEPhdrfile_at,SEPhdrfile);
        strcpy(SEPdatafile_at,SEPdatafile);
	strcat(SEPhdrfile, ".H");
	strcat(SEPhdrfile_at, ".H@@");
        strcat(SEPdatafile, ".H@");
        strcat(SEPdatafile_at, ".H@@@");
	lastf=curf+atoi(argv[2])-1;
	if (argc==4) ssn=atoi(argv[3]); else ssn=1;

#ifdef SEPOUTPUT/* { */
	f2 = fopen(SEPhdrfile, "wb");
	if (f2 == (FILE *) NULL) {
	fprintf (stderr, "**OUTPUT HEADER FILE \"%s\" OPEN FAILURE**\n **ABORTING**\n", SEPhdrfile);
	  exit (-3);
	}

	f2_at = fopen(SEPhdrfile_at, "wb");
	if (f2_at == (FILE *) NULL) {
	fprintf (stderr, "**OUTPUT HEADER FILE \"%s\" OPEN FAILURE**\n **ABORTING**\n", SEPhdrfile_at);
	  exit (-3);
	}

	f3 = fopen(SEPdatafile, "wb");
	if (f3 == (FILE *) NULL) {
	fprintf (stderr, "**OUTPUT DATA FILE \"%s\" OPEN FAILURE**\n **ABORTING**\n", SEPdatafile);
	  exit (-3);
	}

	f3_at = fopen(SEPdatafile_at, "wb");
	if (f3_at == (FILE *) NULL) {
	fprintf (stderr, "**OUTPUT DATA FILE \"%s\" OPEN FAILURE**\n **ABORTING**\n", SEPdatafile_at);
	  exit (-3);
	}
#endif/* } SEPOUTPUT*/

	readSegyKeys (keywords);

	/* start the big loop ... */
	for(; curf<=lastf; curf++) {
	strcpy(seg2file,prefix);
        if(ntoconvert > 1) {
	   sprintf(str,"%d",curf);
	   l=strlen(str);
	   while(l<ln) { strcat(seg2file,"0"); l++; }
	   strcat(seg2file,str);
        }
        strcpy(MATfile,seg2file);
	strcat(seg2file,suffix);
	strcat(MATfile,".mat");

	if ((f1=fopen(seg2file,"rb")) == (FILE *)NULL) {
	fprintf (stderr, "\n***ERROR OPENING FILE %s***\n", seg2file);
	fprintf (stderr, "Skipping to next file number.\n");
	continue;    /* go to end of loop, try next file */
	}

#ifdef MATOUTPUT/* { */
	fm = fopen(MATfile, "wb");
	if (fm == (FILE *) NULL) {
	fprintf (stderr, "**OUTPUT DATA FILE \"%s\" OPEN FAILURE**\n **ABORTING**\n", MATfile);
	  exit (-3);
	}

        fwrite(MatFileHdr,sizeof(char),sizeof(MatFileHdr),fm);
#endif/* } */

#ifdef SEPOUTPUT/* { */
        fprintf(f2,"# INPUT FILE \"%s\":\n",seg2file);
#endif/* } */
	fread (&blockid, 2, 1, f1);
	if (blockid == 0x553a) 
	    reversed = 1-ImLittleEndian;
        else
            reversed = ImLittleEndian;
   
	if (blockid != 0x3a55) {
	    if (!reversed) {
	    fprintf (stderr, "%s Not SEG-2 data can not continue\n",seg2file);
	    exit (-4);
	    }
	}

	fread (&revnum, 2, 1, f1);
	fread (&pointerbytecount, 2, 1, f1);
	fread (&numtrace, 2, 1, f1);
	if (reversed != ImLittleEndian) {
	    swapshort (&revnum);
	    swapshort (&pointerbytecount);
	    swapshort (&numtrace);
	}

	printf ("File %s, Data Format Revision: %u, Number of traces: %u\n", seg2file, (unsigned int) revnum,
                (unsigned int) numtrace);
#ifdef SEPOUTPUT/* { */
	fprintf(f2,"# Data Format Revision: %u, Number of traces: %u\n",
                (unsigned int) revnum, (unsigned int) numtrace);
#endif/* } */
	fread (&stringtermcount, 1, 1, f1);
	fread (&stringterm1, 1, 1, f1);
	fread (&stringterm2, 1, 1, f1);
	fread (&linetermcount, 1, 1, f1);
	fread (&lineterm1, 1, 1, f1);
	fread (&lineterm2, 1, 1, f1);
	fread (reserved, 1, 18, f1);  /* reserved block, not used */

	if (numtrace > (pointerbytecount / 4)) {
	    fprintf (stderr, "Number of traces greater than number of trace pointers\n");
	    fprintf (stderr, "Number of pointers = %u\n", (unsigned int) (pointerbytecount / 4));
	    fprintf (stderr, "Due to this inconsistency processing must stop\n");
	    exit (-5);
	}
	fread (tracepointers, 4, numtrace, f1);
	if (reversed != ImLittleEndian) {
	   for (i = 0; i < numtrace; i++)
	        swaplong (&tracepointers[i]);
	}

#ifdef MATOUTPUT/* { */
        /* start writing out a big matlab structure */
        start_of_seg2_structure = ftello(fm);
        putc('\000',fm); putc('\000',fm); putc('\000',fm);
        putc('\016',fm); /* miMATRIX */
        putc('\000',fm); putc('\000',fm); putc('\000',fm);
        putc('\000',fm); /* byte count to be updated later */
        putc('\000',fm); putc('\000',fm); putc('\000',fm);
        putc('\006',fm); /* miUNIT32 */
        putc('\000',fm); putc('\000',fm); putc('\000',fm);
        putc('\010',fm); /* 8 */
        putc('\000',fm); putc('\000',fm); putc('\000',fm);
        putc('\002',fm); /* mxSTRUCT_CLASS */
        putc('\000',fm); putc('\000',fm); putc('\000',fm);
        putc('\000',fm); /* undefined */
        putc('\000',fm); putc('\000',fm); putc('\000',fm);
        putc('\005',fm); /* miINT32 */
        putc('\000',fm); putc('\000',fm); putc('\000',fm);
        putc('\010',fm); /* 2D file header char array */
        putc('\000',fm); putc('\000',fm); putc('\000',fm);
        putc('\001',fm); /* 1 */
        putc('\000',fm); putc('\000',fm); putc('\000',fm);
        putc('\001',fm); /* x 1 dimensions */
        /* we'll name the structure after the input SEG-2 filename */
        putc('\000',fm); putc('\000',fm); putc('\000',fm);
        putc('\001',fm); /* miINT8 */
        ctmp = strrchr(MATstructname,'/');
        if(ctmp == ((char *) NULL)) ctmp = MATstructname;
        else ++ctmp;
        l = strlen(ctmp)/*-strlen(suffix)*/;
        ul = (uint32_t) l;
        if(ImLittleEndian) swaplong(&ul);
        fwrite(&ul,1,sizeof(ul),fm);/*Structure Name Length */
        fwrite(ctmp,1,l,fm); /* Structure name */
        while(l%8 != 0) { putc('\000',fm); ++l; } /* pad Array name field */
        /* write in four field names: FileHeader, TraceHeaderNames, */
        /* TraceHeaderValues, and TraceDataValues */
        putc('\000',fm); putc('\004', fm); putc('\000',fm);
        putc('\005',fm);
        putc('\000',fm); putc('\000',fm); putc('\000',fm);
        putc('\040',fm); /* max field name length is 32 bytes */
        putc('\000',fm); putc('\000',fm); putc('\000',fm);
        putc('\001',fm); /* miINT8 */
        putc('\000',fm); putc('\000',fm); putc('\000',fm);
        putc('\200',fm); /* 4*32 = 128 bytes of field names */
        memset(fieldNameBuf,'\0',32);
        strcpy(fieldNameBuf,"FileHeader");
        fwrite(fieldNameBuf,1,32,fm);
        memset(fieldNameBuf,'\0',32);
        strcpy(fieldNameBuf,"TraceHeaderNames");
        fwrite(fieldNameBuf,1,32,fm);
        memset(fieldNameBuf,'\0',32);
        strcpy(fieldNameBuf,"TraceHeaderValues");
        fwrite(fieldNameBuf,1,32,fm);
        memset(fieldNameBuf,'\0',32);
        strcpy(fieldNameBuf,"TraceDataValues");
        fwrite(fieldNameBuf,1,32,fm);

        /* write out FileHeader preamble */
        start_of_file_header = ftello(fm);
        putc('\000',fm); putc('\000',fm); putc('\000',fm);
        putc('\016',fm); /* miMATRIX */
        putc('\000',fm); putc('\000',fm); putc('\000',fm);
        putc('\000',fm); /* number of bytes to be filled in later */
        putc('\000',fm); putc('\000',fm); putc('\000',fm);
        putc('\006',fm); /* miUINT32 */
        putc('\000',fm); putc('\000',fm); putc('\000',fm);
        putc('\010',fm); /* 8 */
        putc('\000',fm); putc('\000',fm); putc('\000',fm);
        putc('\004',fm); /* mxCHAR_CLASS */
        putc('\000',fm); putc('\000',fm); putc('\000',fm);
        putc('\000',fm); /* undefined */
        putc('\000',fm); putc('\000',fm); putc('\000',fm);
        putc('\005',fm); /* miINT32 */
        putc('\000',fm); putc('\000',fm); putc('\000',fm);
        putc('\010',fm); /* 8 */
        putc('\000',fm); putc('\000',fm); putc('\000',fm);
        putc(STRINGWIDTH,fm); /* 112 max chars per line (multiple of 8) */
        putc('\000',fm); putc('\000',fm); putc('\000',fm);
        putc('\000',fm); /* number of file header lines to be filled in later */
        putc('\000',fm); putc('\000',fm); putc('\000',fm);
        putc('\001',fm); /* miINT8 */
        putc('\000',fm); putc('\000',fm); putc('\000',fm);
        putc('\000',fm); /* no separate array name in structure */
#endif/* } */
	/* now read file descriptor block.  */
        fseek(f1, 32+pointerbytecount, SEEK_SET);
	fread (&stringlength, 2, 1, f1);
	if (reversed != ImLittleEndian)
	    swapshort (&stringlength);

        if(0 != stringlength) { 
#ifdef SEPOUTPUT/* { */
          fputs("#\n# File Descriptor Block:\n#\n", f2);
#endif/* } */
#ifdef MATOUTPUT/* { */
          putc('\000',fm); putc('\000',fm); putc('\000',fm);
          putc('\020',fm); /* miUTF8 */
          putc('\000',fm); putc('\000',fm); putc('\000',fm);
          putc('\000',fm); /* fill in number of bytes later */
#endif/* } */
	  while (0 != stringlength) {
	    fread (string1, 1, stringlength - 2, f1);
            /* copy file descriptor block strings to output header as comment lines */
#ifdef SEPOUTPUT/* { */
            fputs("# ", f2); fwrite(string1, 1, stringlength - 2 - stringtermcount, f2); fputs("\n", f2);
#endif
            l = stringlength -2 - stringtermcount;
#ifdef MATOUTPUT/* { */
            fwrite(string1, 1, l, fm);
            while(l < STRINGWIDTH) {
               putc('\000',fm);
               ++l;
            }
#endif/* } */
	    keycheck (keywords);
	    fread (&stringlength, 2, 1, f1);
    
	    if (reversed != ImLittleEndian) swapshort (&stringlength);
  	  }
        }

#ifdef MATOUTPUT/* { */
        /* fill in length of file header */
        curr_mat_loc = ftello(fm);
        ul = curr_mat_loc - start_of_file_header - 8;
        fseeko(fm,start_of_file_header+4,SEEK_SET);
        if(ImLittleEndian) swaplong(&ul);
        fwrite(&ul,1,sizeof(ul),fm);
        if(ImLittleEndian) swaplong(&ul);
        ul -= 48;
        ul /= STRINGWIDTH;
        if(ImLittleEndian) swaplong(&ul);
        fseeko(fm,start_of_file_header+36,SEEK_SET);
        fwrite(&ul,1,sizeof(ul),fm); /* number of file header lines */
        if(ImLittleEndian) swaplong(&ul);
        ul *= STRINGWIDTH;
        if(ImLittleEndian) swaplong(&ul);
        fseeko(fm,start_of_file_header+52,SEEK_SET);
        fwrite(&ul,1,sizeof(ul),fm); /* number of bytes of file header */
        fseeko(fm,curr_mat_loc,SEEK_SET);

        /* write out trace header names */
        putc('\000',fm); putc('\000',fm); putc('\000',fm);
        putc('\016',fm); /* miMATRIX */
        ul = sizeof(thdrNameBuf)*sizeof(thdrvals)/sizeof(thdrvals[0])+6*8;
        if(ImLittleEndian) swaplong(&ul);       
        fwrite(&ul,1,sizeof(ul),fm); /* byte count in thdr names array */
        putc('\000',fm); putc('\000',fm); putc('\000',fm);
        putc('\006',fm); /* miUINT32 */
        putc('\000',fm); putc('\000',fm); putc('\000',fm);
        putc('\010',fm); /* 8 */
        putc('\000',fm); putc('\000',fm); putc('\000',fm);
        putc('\004',fm); /* mxCHAR_CLASS */
        putc('\000',fm); putc('\000',fm); putc('\000',fm);
        putc('\000',fm); /* undefined */
        putc('\000',fm); putc('\000',fm); putc('\000',fm);
        putc('\005',fm); /* miINT32 */
        putc('\000',fm); putc('\000',fm); putc('\000',fm);
        putc('\010',fm); /* 8 */
        ul = sizeof(thdrNameBuf);
        if(ImLittleEndian) swaplong(&ul);
        fwrite(&ul,1,sizeof(ul),fm); /* 32 bytes per trace header name */
        ul = sizeof(thdrvals)/sizeof(thdrvals[0]);
        if(ImLittleEndian) swaplong(&ul);
        fwrite(&ul,1,sizeof(ul),fm); /* 87 trace header names */
        putc('\000',fm); putc('\000',fm); putc('\000',fm);
        putc('\001',fm); /* miINT8 */
        putc('\000',fm); putc('\000',fm); putc('\000',fm);
        putc('\000',fm); /* no separate array name in structure */
        putc('\000',fm); putc('\000',fm); putc('\000',fm);
        putc('\020',fm); /* miUTF8 */
        ul = sizeof(thdrNameBuf)*sizeof(thdrvals)/sizeof(thdrvals[0]);
        if(ImLittleEndian) swaplong(&ul);
        fwrite(&ul,1,sizeof(ul),fm); /* 87*32 characters to follow */
        icnt = 1;
        memset(thdrNameBuf,'\0',sizeof(thdrNameBuf));
        sprintf(thdrNameBuf,"%3.3i ",icnt); ++icnt;
        strcat(thdrNameBuf,"tracl");
        fwrite(thdrNameBuf,1,sizeof(thdrNameBuf),fm);
        memset(thdrNameBuf,'\0',sizeof(thdrNameBuf));
        sprintf(thdrNameBuf,"%3.3i ",icnt); ++icnt;
        strcat(thdrNameBuf,"tracr");
        fwrite(thdrNameBuf,1,sizeof(thdrNameBuf),fm);
        memset(thdrNameBuf,'\0',sizeof(thdrNameBuf));
        sprintf(thdrNameBuf,"%3.3i ",icnt); ++icnt;
        strcat(thdrNameBuf,"fldr");
        fwrite(thdrNameBuf,1,sizeof(thdrNameBuf),fm);
        memset(thdrNameBuf,'\0',sizeof(thdrNameBuf));
        sprintf(thdrNameBuf,"%3.3i ",icnt); ++icnt;
        strcat(thdrNameBuf,"tracf");
        fwrite(thdrNameBuf,1,sizeof(thdrNameBuf),fm);
        memset(thdrNameBuf,'\0',sizeof(thdrNameBuf));
        sprintf(thdrNameBuf,"%3.3i ",icnt); ++icnt;
        strcat(thdrNameBuf,"ep");
        fwrite(thdrNameBuf,1,sizeof(thdrNameBuf),fm);
        memset(thdrNameBuf,'\0',sizeof(thdrNameBuf));
        sprintf(thdrNameBuf,"%3.3i ",icnt); ++icnt;
        strcat(thdrNameBuf,"cdp");
        fwrite(thdrNameBuf,1,sizeof(thdrNameBuf),fm);
        memset(thdrNameBuf,'\0',sizeof(thdrNameBuf));
        sprintf(thdrNameBuf,"%3.3i ",icnt); ++icnt;
        strcat(thdrNameBuf,"cdpt");
        fwrite(thdrNameBuf,1,sizeof(thdrNameBuf),fm);
        memset(thdrNameBuf,'\0',sizeof(thdrNameBuf));
        sprintf(thdrNameBuf,"%3.3i ",icnt); ++icnt;
        strcat(thdrNameBuf,"trid");
        fwrite(thdrNameBuf,1,sizeof(thdrNameBuf),fm);
        memset(thdrNameBuf,'\0',sizeof(thdrNameBuf));
        sprintf(thdrNameBuf,"%3.3i ",icnt); ++icnt;
        strcat(thdrNameBuf,"nvs");
        fwrite(thdrNameBuf,1,sizeof(thdrNameBuf),fm);
        memset(thdrNameBuf,'\0',sizeof(thdrNameBuf));
        sprintf(thdrNameBuf,"%3.3i ",icnt); ++icnt;
        strcat(thdrNameBuf,"nhs");
        fwrite(thdrNameBuf,1,sizeof(thdrNameBuf),fm);
        memset(thdrNameBuf,'\0',sizeof(thdrNameBuf));
        sprintf(thdrNameBuf,"%3.3i ",icnt); ++icnt;
        strcat(thdrNameBuf,"duse");
        fwrite(thdrNameBuf,1,sizeof(thdrNameBuf),fm);
        memset(thdrNameBuf,'\0',sizeof(thdrNameBuf));
        sprintf(thdrNameBuf,"%3.3i ",icnt); ++icnt;
        strcat(thdrNameBuf,"offset");
        fwrite(thdrNameBuf,1,sizeof(thdrNameBuf),fm);
        memset(thdrNameBuf,'\0',sizeof(thdrNameBuf));
        sprintf(thdrNameBuf,"%3.3i ",icnt); ++icnt;
        strcat(thdrNameBuf,"gelev");
        fwrite(thdrNameBuf,1,sizeof(thdrNameBuf),fm);
        memset(thdrNameBuf,'\0',sizeof(thdrNameBuf));
        sprintf(thdrNameBuf,"%3.3i ",icnt); ++icnt;
        strcat(thdrNameBuf,"selev");
        fwrite(thdrNameBuf,1,sizeof(thdrNameBuf),fm);
        memset(thdrNameBuf,'\0',sizeof(thdrNameBuf));
        sprintf(thdrNameBuf,"%3.3i ",icnt); ++icnt;
        strcat(thdrNameBuf,"sdepth");
        fwrite(thdrNameBuf,1,sizeof(thdrNameBuf),fm);
        memset(thdrNameBuf,'\0',sizeof(thdrNameBuf));
        sprintf(thdrNameBuf,"%3.3i ",icnt); ++icnt;
        strcat(thdrNameBuf,"gdel");
        fwrite(thdrNameBuf,1,sizeof(thdrNameBuf),fm);
        memset(thdrNameBuf,'\0',sizeof(thdrNameBuf));
        sprintf(thdrNameBuf,"%3.3i ",icnt); ++icnt;
        strcat(thdrNameBuf,"sdel");
        fwrite(thdrNameBuf,1,sizeof(thdrNameBuf),fm);
        memset(thdrNameBuf,'\0',sizeof(thdrNameBuf));
        sprintf(thdrNameBuf,"%3.3i ",icnt); ++icnt;
        strcat(thdrNameBuf,"swdep");
        fwrite(thdrNameBuf,1,sizeof(thdrNameBuf),fm);
        memset(thdrNameBuf,'\0',sizeof(thdrNameBuf));
        sprintf(thdrNameBuf,"%3.3i ",icnt); ++icnt;
        strcat(thdrNameBuf,"gwdep");
        fwrite(thdrNameBuf,1,sizeof(thdrNameBuf),fm);
        memset(thdrNameBuf,'\0',sizeof(thdrNameBuf));
        sprintf(thdrNameBuf,"%3.3i ",icnt); ++icnt;
        strcat(thdrNameBuf,"scalel");
        fwrite(thdrNameBuf,1,sizeof(thdrNameBuf),fm);
        memset(thdrNameBuf,'\0',sizeof(thdrNameBuf));
        sprintf(thdrNameBuf,"%3.3i ",icnt); ++icnt;
        strcat(thdrNameBuf,"scaleco");
        fwrite(thdrNameBuf,1,sizeof(thdrNameBuf),fm);
        memset(thdrNameBuf,'\0',sizeof(thdrNameBuf));
        sprintf(thdrNameBuf,"%3.3i ",icnt); ++icnt;
        strcat(thdrNameBuf,"sx");
        fwrite(thdrNameBuf,1,sizeof(thdrNameBuf),fm);
        memset(thdrNameBuf,'\0',sizeof(thdrNameBuf));
        sprintf(thdrNameBuf,"%3.3i ",icnt); ++icnt;
        strcat(thdrNameBuf,"sy");
        fwrite(thdrNameBuf,1,sizeof(thdrNameBuf),fm);
        memset(thdrNameBuf,'\0',sizeof(thdrNameBuf));
        sprintf(thdrNameBuf,"%3.3i ",icnt); ++icnt;
        strcat(thdrNameBuf,"gx");
        fwrite(thdrNameBuf,1,sizeof(thdrNameBuf),fm);
        memset(thdrNameBuf,'\0',sizeof(thdrNameBuf));
        sprintf(thdrNameBuf,"%3.3i ",icnt); ++icnt;
        strcat(thdrNameBuf,"gy");
        fwrite(thdrNameBuf,1,sizeof(thdrNameBuf),fm);
        memset(thdrNameBuf,'\0',sizeof(thdrNameBuf));
        sprintf(thdrNameBuf,"%3.3i ",icnt); ++icnt;
        strcat(thdrNameBuf,"counit");
        fwrite(thdrNameBuf,1,sizeof(thdrNameBuf),fm);
        memset(thdrNameBuf,'\0',sizeof(thdrNameBuf));
        sprintf(thdrNameBuf,"%3.3i ",icnt); ++icnt;
        strcat(thdrNameBuf,"welev");
        fwrite(thdrNameBuf,1,sizeof(thdrNameBuf),fm);
        memset(thdrNameBuf,'\0',sizeof(thdrNameBuf));
        sprintf(thdrNameBuf,"%3.3i ",icnt); ++icnt;
        strcat(thdrNameBuf,"swelev");
        fwrite(thdrNameBuf,1,sizeof(thdrNameBuf),fm);
        memset(thdrNameBuf,'\0',sizeof(thdrNameBuf));
        sprintf(thdrNameBuf,"%3.3i ",icnt); ++icnt;
        strcat(thdrNameBuf,"sut");
        fwrite(thdrNameBuf,1,sizeof(thdrNameBuf),fm);
        memset(thdrNameBuf,'\0',sizeof(thdrNameBuf));
        sprintf(thdrNameBuf,"%3.3i ",icnt); ++icnt;
        strcat(thdrNameBuf,"gut");
        fwrite(thdrNameBuf,1,sizeof(thdrNameBuf),fm);
        memset(thdrNameBuf,'\0',sizeof(thdrNameBuf));
        sprintf(thdrNameBuf,"%3.3i ",icnt); ++icnt;
        strcat(thdrNameBuf,"sstat");
        fwrite(thdrNameBuf,1,sizeof(thdrNameBuf),fm);
        memset(thdrNameBuf,'\0',sizeof(thdrNameBuf));
        sprintf(thdrNameBuf,"%3.3i ",icnt); ++icnt;
        strcat(thdrNameBuf,"gstat");
        fwrite(thdrNameBuf,1,sizeof(thdrNameBuf),fm);
        memset(thdrNameBuf,'\0',sizeof(thdrNameBuf));
        sprintf(thdrNameBuf,"%3.3i ",icnt); ++icnt;
        strcat(thdrNameBuf,"tstat");
        fwrite(thdrNameBuf,1,sizeof(thdrNameBuf),fm);
        memset(thdrNameBuf,'\0',sizeof(thdrNameBuf));
        sprintf(thdrNameBuf,"%3.3i ",icnt); ++icnt;
        strcat(thdrNameBuf,"laga");
        fwrite(thdrNameBuf,1,sizeof(thdrNameBuf),fm);
        memset(thdrNameBuf,'\0',sizeof(thdrNameBuf));
        sprintf(thdrNameBuf,"%3.3i ",icnt); ++icnt;
        strcat(thdrNameBuf,"lagb");
        fwrite(thdrNameBuf,1,sizeof(thdrNameBuf),fm);
        memset(thdrNameBuf,'\0',sizeof(thdrNameBuf));
        sprintf(thdrNameBuf,"%3.3i ",icnt); ++icnt;
        strcat(thdrNameBuf,"delrt");
        fwrite(thdrNameBuf,1,sizeof(thdrNameBuf),fm);
        memset(thdrNameBuf,'\0',sizeof(thdrNameBuf));
        sprintf(thdrNameBuf,"%3.3i ",icnt); ++icnt;
        strcat(thdrNameBuf,"muts");
        fwrite(thdrNameBuf,1,sizeof(thdrNameBuf),fm);
        memset(thdrNameBuf,'\0',sizeof(thdrNameBuf));
        sprintf(thdrNameBuf,"%3.3i ",icnt); ++icnt;
        strcat(thdrNameBuf,"mute");
        fwrite(thdrNameBuf,1,sizeof(thdrNameBuf),fm);
        memset(thdrNameBuf,'\0',sizeof(thdrNameBuf));
        sprintf(thdrNameBuf,"%3.3i ",icnt); ++icnt;
        strcat(thdrNameBuf,"ns");
        fwrite(thdrNameBuf,1,sizeof(thdrNameBuf),fm);
        memset(thdrNameBuf,'\0',sizeof(thdrNameBuf));
        sprintf(thdrNameBuf,"%3.3i ",icnt); ++icnt;
        strcat(thdrNameBuf,"dt");
        fwrite(thdrNameBuf,1,sizeof(thdrNameBuf),fm);
        memset(thdrNameBuf,'\0',sizeof(thdrNameBuf));
        sprintf(thdrNameBuf,"%3.3i ",icnt); ++icnt;
        strcat(thdrNameBuf,"gain");
        fwrite(thdrNameBuf,1,sizeof(thdrNameBuf),fm);
        memset(thdrNameBuf,'\0',sizeof(thdrNameBuf));
        sprintf(thdrNameBuf,"%3.3i ",icnt); ++icnt;
        strcat(thdrNameBuf,"igc");
        fwrite(thdrNameBuf,1,sizeof(thdrNameBuf),fm);
        memset(thdrNameBuf,'\0',sizeof(thdrNameBuf));
        sprintf(thdrNameBuf,"%3.3i ",icnt); ++icnt;
        strcat(thdrNameBuf,"igi");
        fwrite(thdrNameBuf,1,sizeof(thdrNameBuf),fm);
        memset(thdrNameBuf,'\0',sizeof(thdrNameBuf));
        sprintf(thdrNameBuf,"%3.3i ",icnt); ++icnt;
        strcat(thdrNameBuf,"corr");
        fwrite(thdrNameBuf,1,sizeof(thdrNameBuf),fm);
        memset(thdrNameBuf,'\0',sizeof(thdrNameBuf));
        sprintf(thdrNameBuf,"%3.3i ",icnt); ++icnt;
        strcat(thdrNameBuf,"sfs");
        fwrite(thdrNameBuf,1,sizeof(thdrNameBuf),fm);
        memset(thdrNameBuf,'\0',sizeof(thdrNameBuf));
        sprintf(thdrNameBuf,"%3.3i ",icnt); ++icnt;
        strcat(thdrNameBuf,"sfe");
        fwrite(thdrNameBuf,1,sizeof(thdrNameBuf),fm);
        memset(thdrNameBuf,'\0',sizeof(thdrNameBuf));
        sprintf(thdrNameBuf,"%3.3i ",icnt); ++icnt;
        strcat(thdrNameBuf,"slen");
        fwrite(thdrNameBuf,1,sizeof(thdrNameBuf),fm);
        memset(thdrNameBuf,'\0',sizeof(thdrNameBuf));
        sprintf(thdrNameBuf,"%3.3i ",icnt); ++icnt;
        strcat(thdrNameBuf,"styp");
        fwrite(thdrNameBuf,1,sizeof(thdrNameBuf),fm);
        memset(thdrNameBuf,'\0',sizeof(thdrNameBuf));
        sprintf(thdrNameBuf,"%3.3i ",icnt); ++icnt;
        strcat(thdrNameBuf,"stas");
        fwrite(thdrNameBuf,1,sizeof(thdrNameBuf),fm);
        memset(thdrNameBuf,'\0',sizeof(thdrNameBuf));
        sprintf(thdrNameBuf,"%3.3i ",icnt); ++icnt;
        strcat(thdrNameBuf,"stae");
        fwrite(thdrNameBuf,1,sizeof(thdrNameBuf),fm);
        memset(thdrNameBuf,'\0',sizeof(thdrNameBuf));
        sprintf(thdrNameBuf,"%3.3i ",icnt); ++icnt;
        strcat(thdrNameBuf,"tatyp");
        fwrite(thdrNameBuf,1,sizeof(thdrNameBuf),fm);
        memset(thdrNameBuf,'\0',sizeof(thdrNameBuf));
        sprintf(thdrNameBuf,"%3.3i ",icnt); ++icnt;
        strcat(thdrNameBuf,"afilf");
        fwrite(thdrNameBuf,1,sizeof(thdrNameBuf),fm);
        memset(thdrNameBuf,'\0',sizeof(thdrNameBuf));
        sprintf(thdrNameBuf,"%3.3i ",icnt); ++icnt;
        strcat(thdrNameBuf,"afils");
        fwrite(thdrNameBuf,1,sizeof(thdrNameBuf),fm);
        memset(thdrNameBuf,'\0',sizeof(thdrNameBuf));
        sprintf(thdrNameBuf,"%3.3i ",icnt); ++icnt;
        strcat(thdrNameBuf,"nofilf");
        fwrite(thdrNameBuf,1,sizeof(thdrNameBuf),fm);
        memset(thdrNameBuf,'\0',sizeof(thdrNameBuf));
        sprintf(thdrNameBuf,"%3.3i ",icnt); ++icnt;
        strcat(thdrNameBuf,"nofils");
        fwrite(thdrNameBuf,1,sizeof(thdrNameBuf),fm);
        memset(thdrNameBuf,'\0',sizeof(thdrNameBuf));
        sprintf(thdrNameBuf,"%3.3i ",icnt); ++icnt;
        strcat(thdrNameBuf,"lcf");
        fwrite(thdrNameBuf,1,sizeof(thdrNameBuf),fm);
        memset(thdrNameBuf,'\0',sizeof(thdrNameBuf));
        sprintf(thdrNameBuf,"%3.3i ",icnt); ++icnt;
        strcat(thdrNameBuf,"hcf");
        fwrite(thdrNameBuf,1,sizeof(thdrNameBuf),fm);
        memset(thdrNameBuf,'\0',sizeof(thdrNameBuf));
        sprintf(thdrNameBuf,"%3.3i ",icnt); ++icnt;
        strcat(thdrNameBuf,"lcs");
        fwrite(thdrNameBuf,1,sizeof(thdrNameBuf),fm);
        memset(thdrNameBuf,'\0',sizeof(thdrNameBuf));
        sprintf(thdrNameBuf,"%3.3i ",icnt); ++icnt;
        strcat(thdrNameBuf,"hcs");
        fwrite(thdrNameBuf,1,sizeof(thdrNameBuf),fm);
        memset(thdrNameBuf,'\0',sizeof(thdrNameBuf));
        sprintf(thdrNameBuf,"%3.3i ",icnt); ++icnt;
        strcat(thdrNameBuf,"year");
        fwrite(thdrNameBuf,1,sizeof(thdrNameBuf),fm);
        memset(thdrNameBuf,'\0',sizeof(thdrNameBuf));
        sprintf(thdrNameBuf,"%3.3i ",icnt); ++icnt;
        strcat(thdrNameBuf,"day");
        fwrite(thdrNameBuf,1,sizeof(thdrNameBuf),fm);
        memset(thdrNameBuf,'\0',sizeof(thdrNameBuf));
        sprintf(thdrNameBuf,"%3.3i ",icnt); ++icnt;
        strcat(thdrNameBuf,"hour");
        fwrite(thdrNameBuf,1,sizeof(thdrNameBuf),fm);
        memset(thdrNameBuf,'\0',sizeof(thdrNameBuf));
        sprintf(thdrNameBuf,"%3.3i ",icnt); ++icnt;
        strcat(thdrNameBuf,"minute");
        fwrite(thdrNameBuf,1,sizeof(thdrNameBuf),fm);
        memset(thdrNameBuf,'\0',sizeof(thdrNameBuf));
        sprintf(thdrNameBuf,"%3.3i ",icnt); ++icnt;
        strcat(thdrNameBuf,"sec");
        fwrite(thdrNameBuf,1,sizeof(thdrNameBuf),fm);
        memset(thdrNameBuf,'\0',sizeof(thdrNameBuf));
        sprintf(thdrNameBuf,"%3.3i ",icnt); ++icnt;
        strcat(thdrNameBuf,"timbas");
        fwrite(thdrNameBuf,1,sizeof(thdrNameBuf),fm);
        memset(thdrNameBuf,'\0',sizeof(thdrNameBuf));
        sprintf(thdrNameBuf,"%3.3i ",icnt); ++icnt;
        strcat(thdrNameBuf,"trwf");
        fwrite(thdrNameBuf,1,sizeof(thdrNameBuf),fm);
        memset(thdrNameBuf,'\0',sizeof(thdrNameBuf));
        sprintf(thdrNameBuf,"%3.3i ",icnt); ++icnt;
        strcat(thdrNameBuf,"grnors");
        fwrite(thdrNameBuf,1,sizeof(thdrNameBuf),fm);
        memset(thdrNameBuf,'\0',sizeof(thdrNameBuf));
        sprintf(thdrNameBuf,"%3.3i ",icnt); ++icnt;
        strcat(thdrNameBuf,"grnofr");
        fwrite(thdrNameBuf,1,sizeof(thdrNameBuf),fm);
        memset(thdrNameBuf,'\0',sizeof(thdrNameBuf));
        sprintf(thdrNameBuf,"%3.3i ",icnt); ++icnt;
        strcat(thdrNameBuf,"grnlof");
        fwrite(thdrNameBuf,1,sizeof(thdrNameBuf),fm);
        memset(thdrNameBuf,'\0',sizeof(thdrNameBuf));
        sprintf(thdrNameBuf,"%3.3i ",icnt); ++icnt;
        strcat(thdrNameBuf,"gaps");
        fwrite(thdrNameBuf,1,sizeof(thdrNameBuf),fm);
        memset(thdrNameBuf,'\0',sizeof(thdrNameBuf));
        sprintf(thdrNameBuf,"%3.3i ",icnt); ++icnt;
        strcat(thdrNameBuf,"otrav");
        fwrite(thdrNameBuf,1,sizeof(thdrNameBuf),fm);
        memset(thdrNameBuf,'\0',sizeof(thdrNameBuf));
        sprintf(thdrNameBuf,"%3.3i ",icnt); ++icnt;
        strcat(thdrNameBuf,"gxflt");
        fwrite(thdrNameBuf,1,sizeof(thdrNameBuf),fm);
        memset(thdrNameBuf,'\0',sizeof(thdrNameBuf));
        sprintf(thdrNameBuf,"%3.3i ",icnt); ++icnt;
        strcat(thdrNameBuf,"gyflt");
        fwrite(thdrNameBuf,1,sizeof(thdrNameBuf),fm);
        memset(thdrNameBuf,'\0',sizeof(thdrNameBuf));
        sprintf(thdrNameBuf,"%3.3i ",icnt); ++icnt;
        strcat(thdrNameBuf,"sxflt");
        fwrite(thdrNameBuf,1,sizeof(thdrNameBuf),fm);
        memset(thdrNameBuf,'\0',sizeof(thdrNameBuf));
        sprintf(thdrNameBuf,"%3.3i ",icnt); ++icnt;
        strcat(thdrNameBuf,"syflt");
        fwrite(thdrNameBuf,1,sizeof(thdrNameBuf),fm);
        memset(thdrNameBuf,'\0',sizeof(thdrNameBuf));
        sprintf(thdrNameBuf,"%3.3i ",icnt); ++icnt;
        strcat(thdrNameBuf,"gelevflt");
        fwrite(thdrNameBuf,1,sizeof(thdrNameBuf),fm);
        memset(thdrNameBuf,'\0',sizeof(thdrNameBuf));
        sprintf(thdrNameBuf,"%3.3i ",icnt); ++icnt;
        strcat(thdrNameBuf,"selevflt");
        fwrite(thdrNameBuf,1,sizeof(thdrNameBuf),fm);
        memset(thdrNameBuf,'\0',sizeof(thdrNameBuf));
        sprintf(thdrNameBuf,"%3.3i ",icnt); ++icnt;
        strcat(thdrNameBuf,"sdepthflt");
        fwrite(thdrNameBuf,1,sizeof(thdrNameBuf),fm);
        memset(thdrNameBuf,'\0',sizeof(thdrNameBuf));
        sprintf(thdrNameBuf,"%3.3i ",icnt); ++icnt;
        strcat(thdrNameBuf,"gdelflt");
        fwrite(thdrNameBuf,1,sizeof(thdrNameBuf),fm);
        memset(thdrNameBuf,'\0',sizeof(thdrNameBuf));
        sprintf(thdrNameBuf,"%3.3i ",icnt); ++icnt;
        strcat(thdrNameBuf,"sdelflt");
        fwrite(thdrNameBuf,1,sizeof(thdrNameBuf),fm);
        memset(thdrNameBuf,'\0',sizeof(thdrNameBuf));
        sprintf(thdrNameBuf,"%3.3i ",icnt); ++icnt;
        strcat(thdrNameBuf,"swdepflt");
        fwrite(thdrNameBuf,1,sizeof(thdrNameBuf),fm);
        memset(thdrNameBuf,'\0',sizeof(thdrNameBuf));
        sprintf(thdrNameBuf,"%3.3i ",icnt); ++icnt;
        strcat(thdrNameBuf,"gwdepflt");
        fwrite(thdrNameBuf,1,sizeof(thdrNameBuf),fm);
        memset(thdrNameBuf,'\0',sizeof(thdrNameBuf));
        sprintf(thdrNameBuf,"%3.3i ",icnt); ++icnt;
        strcat(thdrNameBuf,"modsernum");
        fwrite(thdrNameBuf,1,sizeof(thdrNameBuf),fm);
        memset(thdrNameBuf,'\0',sizeof(thdrNameBuf));
        sprintf(thdrNameBuf,"%3.3i ",icnt); ++icnt;
        strcat(thdrNameBuf,"senscalibdb");
        fwrite(thdrNameBuf,1,sizeof(thdrNameBuf),fm);
        memset(thdrNameBuf,'\0',sizeof(thdrNameBuf));
        sprintf(thdrNameBuf,"%3.3i ",icnt); ++icnt;
        strcat(thdrNameBuf,"sensorientvertical");
        fwrite(thdrNameBuf,1,sizeof(thdrNameBuf),fm);
        memset(thdrNameBuf,'\0',sizeof(thdrNameBuf));
        sprintf(thdrNameBuf,"%3.3i ",icnt); ++icnt;
        strcat(thdrNameBuf,"sensorientinline");
        fwrite(thdrNameBuf,1,sizeof(thdrNameBuf),fm);
        memset(thdrNameBuf,'\0',sizeof(thdrNameBuf));
        sprintf(thdrNameBuf,"%3.3i ",icnt); ++icnt;
        strcat(thdrNameBuf,"sensorientcrossline");
        fwrite(thdrNameBuf,1,sizeof(thdrNameBuf),fm);

        /* write out trace header data preamble */
        putc('\000',fm); putc('\000',fm); putc('\000',fm);
        putc('\016',fm); /* miMATRIX */
        ul = numtrace*sizeof(double)*sizeof(thdrvals)/sizeof(thdrvals[0])+6*8;
        if(ImLittleEndian) swaplong(&ul);       
        fwrite(&ul,1,sizeof(ul),fm); /* byte count in thdr array */
        putc('\000',fm); putc('\000',fm); putc('\000',fm);
        putc('\006',fm); /* miUINT32 */
        putc('\000',fm); putc('\000',fm); putc('\000',fm);
        putc('\010',fm); /* 8 */
        putc('\000',fm); putc('\000',fm); putc('\000',fm);
        putc('\006',fm); /* mxDOUBLE_CLASS */
        putc('\000',fm); putc('\000',fm); putc('\000',fm);
        putc('\000',fm); /* undefined */
        putc('\000',fm); putc('\000',fm); putc('\000',fm);
        putc('\005',fm); /* miINT32 */
        putc('\000',fm); putc('\000',fm); putc('\000',fm);
        putc('\010',fm); /* 8 */
        ul = sizeof(thdrvals)/sizeof(thdrvals[0]);
        if(ImLittleEndian) swaplong(&ul);
        fwrite(&ul,1,sizeof(ul),fm); /* 87 values per header */
        ul = numtrace;
        if(ImLittleEndian) swaplong(&ul);
        fwrite(&ul,1,sizeof(ul),fm); /* and numtrace headers */
        putc('\000',fm); putc('\000',fm); putc('\000',fm);
        putc('\001',fm); /* miINT8 */
        putc('\000',fm); putc('\000',fm); putc('\000',fm);
        putc('\000',fm); /* no separate array name */
        putc('\000',fm); putc('\000',fm); putc('\000',fm);
        putc('\011',fm); /* miDOUBLE */
        ul = numtrace*sizeof(double)*sizeof(thdrvals)/sizeof(thdrvals[0]);
        if(ImLittleEndian) swaplong(&ul);
        fwrite(&ul,1,sizeof(ul),fm); /* 87*numtrace doubles to follow */
        current_trace_header = ftello(fm);
        if(ImLittleEndian) swaplong(&ul);
        for(l=0; l<ul; ++l) putc('\000',fm); /* zero header buffer on disk */

        /* now write trace data preamble */
        start_of_trace_data = ftello(fm);
        putc('\000',fm); putc('\000',fm); putc('\000',fm);
        putc('\016',fm); /* miMATRIX */
        putc('\000',fm); putc('\000',fm); putc('\000',fm);
        putc('\000',fm); /* fill in length later */
        putc('\000',fm); putc('\000',fm); putc('\000',fm);
        putc('\006',fm); /* miUINT32 */
        putc('\000',fm); putc('\000',fm); putc('\000',fm);
        putc('\010',fm); /* 8 */
        putc('\000',fm); putc('\000',fm); putc('\000',fm);
        putc('\006',fm); /* mxDOUBLE_CLASS */
        putc('\000',fm); putc('\000',fm); putc('\000',fm);
        putc('\000',fm); /* undefined */
        putc('\000',fm); putc('\000',fm); putc('\000',fm);
        putc('\005',fm); /* miINT32 */
        putc('\000',fm); putc('\000',fm); putc('\000',fm);
        putc('\010',fm); /* 8 */
        putc('\000',fm); putc('\000',fm); putc('\000',fm);
        putc('\000',fm); /* fill in numsamples later */
        ul = numtrace;
        if(ImLittleEndian) swaplong(&ul);
        fwrite(&ul,1,sizeof(ul),fm); /* and numtrace traces */
        putc('\000',fm); putc('\000',fm); putc('\000',fm);
        putc('\001',fm); /* miINT8 */
        putc('\000',fm); putc('\000',fm); putc('\000',fm);
        putc('\000',fm); /* no separate array name */
        putc('\000',fm); putc('\000',fm); putc('\000',fm);
        putc('\011',fm); /* miDOUBLE */
        putc('\000',fm); putc('\000',fm); putc('\000',fm);
        putc('\000',fm); /* fill in number of bytes trace data later */

        current_trace_data = ftello(fm);
#endif/* } */

	for (j = 0; j < numtrace; j++) {
	  fprintf (stderr, "trace-%d-\r", j + 1); fflush(stderr);
	  fseek (f1, tracepointers[j], SEEK_SET);
	  fread (&blockid, 2, 1, f1);
	  if (reversed != ImLittleEndian)
	      swapshort (&blockid);
	  if (blockid == 0x2244) {
	    /* reversed=1; should already know this */
	    fprintf (stderr, "Oops, blockid %hx! I've blown it here.... (line:%d)\n", (unsigned short) blockid, __LINE__);
	    exit (-6);
	  }
	  if (blockid != 0x4422) {
	    fprintf (stderr, "Not a SEG-2 trace header.  Can not process %hx (line %d)\n", 
                     (unsigned short) blockid, __LINE__);
	    exit (-7);
	  }
	  fread (&blockleng, 2, 1, f1);
	  if (reversed != ImLittleEndian)
	      swapshort ((uint16_t *) &blockleng);
	  fread (&datalength, 4, 1, f1);
	  if (reversed != ImLittleEndian)
	      swaplong ((uint32_t *) &datalength);
	  fread (&numsamples, 4, 1, f1);
	  if (reversed != ImLittleEndian)
	     swaplong ((uint32_t *) &numsamples);
	  if (numsamples >= MAXSAMP){ 
	     fprintf(stderr, "Your data contains more samples than I can handle\n");
	     exit(-8);
  	  }
	  fread (&datatype, 1, 1, f1);
	  if (datatype > 5 || datatype < 1) {
	    fprintf (stderr,"Data type %d not available/valid\n", (int) datatype);
	    break;
	  }
	  outhead[57] = (uint16_t) numsamples;
	  fread (reserved, 1, 19, f1);
	  fread (&stringlength, 2, 1, f1);
	  if (reversed != ImLittleEndian)
	      swapshort (&stringlength);
#ifdef SEPOUTPUT/* { */
          if(0 != stringlength)
              fprintf(f2,"#\n#File %u Trace %u:\n#\n",ssn, j+1);
#endif/* } */
	  while (0 != stringlength) {
	      fread (string1, 1, stringlength - 2, f1);
              /* copy trace descriptor block strings to output header as comment lines */
#ifdef SEPOUTPUT/* { */
              fputs("# ", f2); fwrite(string1, 1, stringlength - 2 - stringtermcount, f2); fputs("\n", f2);
#endif/* } */
	      keycheck (keywords);
	      fread (&stringlength, 2, 1, f1);
	      if (reversed != ImLittleEndian)
	          swapshort (&stringlength);
	  }
	
	  fseek (f1, blockleng + tracepointers[j], SEEK_SET);
	  switch ((int) datatype)
	  {
	case 1: /* two byte signed integer */
		fread (iinbuf, 2, (int) numsamples, f1);
		if (reversed != ImLittleEndian) {
		    for (i = 0; i < (int) numsamples; i++)
		        swapshort (iinbuf+i);
		}
		break;
	case 2: /* 4 byte signed integer */
		fread (linbuf, 4, (int) numsamples, f1);
		if (reversed != ImLittleEndian) {
		    for (i = 0; i < (int) numsamples; i++)
		        swaplong (linbuf+i);
		}
		break;
	case 3: /* SEG-D 20 bit binary */
	{
		uint32_t totalbytes, subpointer;
		uint16_t expo;
		int32_t longdat;
		uint16_t sdata; /*modified version by PM */
		totalbytes = (numsamples * 5) / 2;
		fread (cinbuf, 1, (size_t) totalbytes, f1);

	/*modified version by P.Michaels <pm@cgiss.boisestate.edu> */
	/*fixes sawtooth conversion error on large negative values */
        /*further modified by Stewart A. Levin <stew@sep.stanford.edu> */
        /*to honor the actual format (1's complement mantissa) */
		for (k = 0; k < (numsamples);) {
		subpointer = (k / 4) * 5;
		expo = iinbuf[subpointer++];
                if (reversed != ImLittleEndian)
                    swapshort(&expo);
		for (i = 0; i < 4; i++) {
	                sdata=iinbuf[subpointer++];
                        if(reversed != ImLittleEndian) 
                             swapshort(&sdata);
                        if (sdata<0x8000) /* nonnegative */
                           {       
                             longdat=(long) sdata;
                             longdat=longdat << (0x000f & expo);
                           }       
                	else    
                           {       
                             longdat= sdata^0xffff; 
                             longdat=longdat << (0x000f & expo);
                             longdat = -longdat; 
                           } /* endif */ 
                        expo >>= 4;
		        outbuf[k++] = *((uint32_t *) (&longdat));
                    } /* next i */
        	} /* next k */
		/* end of modifications */
	}
	break;
	case 4: /* IEEE single precision */
	if(((int) numsamples) != fread (finbuf, 4, (int) numsamples, f1)) {
		fprintf(stderr,"short trace read!\n");
                if(feof(f1)) fprintf(stderr,"EOF\n");
                if(ferror(f1)) fprintf(stderr,"ERR\n");
                fprintf(stderr,"offset=%ld\n", ftell(f1));
                }
		if (reversed != ImLittleEndian) {
		    for (i = 0; i < numsamples; i++)
		        swaplong (linbuf+i);
		}
        break;         
	case 5: /* IEEE double precision */
	fread (dinbuf, 8, (int) numsamples, f1);
		if (reversed != ImLittleEndian) {
		    for (i = 0; i < numsamples*2; i += 2) {
                        uint32_t templ5;
		        swaplong (linbuf+i);
                        swaplong (linbuf+i+1);
                        templ5 = linbuf[i];
                        linbuf[i] = linbuf[i+1];
                        linbuf[i+1] = templ5;
                    }
		}
         break;
         default:
         break;
	}      /* end switch */

	/* assign the original field record number as the current file number */
	if (outheadl[2] == 0) outheadl[2] = (long) curf;
	/* set trace type  as  sesmic data */
	if (outhead[14] == 0) outhead[14] = 1;

	/* set last trace flag (modified segy) */
	if (j == numtrace - 1 && outhead[87] == 0) {
	outhead[87] = 1;
	ssn = ssn + 1;
	}

        /* compute precision scalars for depths and elevations */
        {
           float curabs1;
           float maxabs1 = 0.0f;
           double scalar1;
           curabs1 = *((float *) (outhead+20));  if(curabs1 < 0.0f) curabs1 = -curabs1; 
                                                 if(curabs1 > maxabs1) maxabs1 = curabs1;
           curabs1 = *((float *) (outhead+22));  if(curabs1 < 0.0f) curabs1 = -curabs1; 
                                                 if(curabs1 > maxabs1) maxabs1 = curabs1;
           curabs1 = *((float *) (outhead+24));  if(curabs1 < 0.0f) curabs1 = -curabs1; 
                                                 if(curabs1 > maxabs1) maxabs1 = curabs1;
           curabs1 = *((float *) (outhead+26));  if(curabs1 < 0.0f) curabs1 = -curabs1; 
                                                 if(curabs1 > maxabs1) maxabs1 = curabs1;
           curabs1 = *((float *) (outhead+28));  if(curabs1 < 0.0f) curabs1 = -curabs1; 
                                                 if(curabs1 > maxabs1) maxabs1 = curabs1;
           curabs1 = *((float *) (outhead+30));  if(curabs1 < 0.0f) curabs1 = -curabs1; 
                                                 if(curabs1 > maxabs1) maxabs1 = curabs1;
           curabs1 = *((float *) (outhead+32));  if(curabs1 < 0.0f) curabs1 = -curabs1; 
                                                 if(curabs1 > maxabs1) maxabs1 = curabs1;
           if(maxabs1 < 214748.3648f) {
              *((int16_t *) (outhead+34)) = -10000; scalar1 = 10000.0;
           } else if(maxabs1 < 2147483.648f) {
              *((int16_t *) (outhead+34)) = -1000; scalar1 = 1000.0;
           } else if(maxabs1 < 21474836.48f) {
              *((int16_t *) (outhead+34)) = -100; scalar1 = 100.0;
           } else if(maxabs1 < 214748364.8f) {
              *((int16_t *) (outhead+34)) = -10; scalar1 = 10.0;
           } else if(maxabs1 < 2147483648.0f) {
              *((int16_t *) (outhead+34)) = 1; scalar1 = 1.0;
           } else if(maxabs1 < 21474836480.0f) {
              *((int16_t *) (outhead+34)) = 10; scalar1 = 0.1;
           } else if(maxabs1 < 214748364800.0f) {
              *((int16_t *) (outhead+34)) = 100; scalar1 = 0.01;
           } else if(maxabs1 < 2147483648000.0f) {
              *((int16_t *) (outhead+34)) = 1000; scalar1 = 0.001;
           } else {
              *((int16_t *) (outhead+34)) = 10000; scalar1 = 0.0001;
           } 
           thdrvals[75] = *((int32_t *) (outhead+20));
           curabs1 = *((float *) (outhead+20));  *((int32_t *) (outhead+20)) = (int32_t) rint(curabs1*scalar1); 
           thdrvals[76] = *((int32_t *) (outhead+22));
           curabs1 = *((float *) (outhead+22));  *((int32_t *) (outhead+22)) = (int32_t) rint(curabs1*scalar1); 
           thdrvals[77] = *((int32_t *) (outhead+24));
           curabs1 = *((float *) (outhead+24));  *((int32_t *) (outhead+24)) = (int32_t) rint(curabs1*scalar1); 
           thdrvals[78] = *((int32_t *) (outhead+26));
           curabs1 = *((float *) (outhead+26));  *((int32_t *) (outhead+26)) = (int32_t) rint(curabs1*scalar1); 
           thdrvals[79] = *((int32_t *) (outhead+28));
           curabs1 = *((float *) (outhead+28));  *((int32_t *) (outhead+28)) = (int32_t) rint(curabs1*scalar1); 
           thdrvals[80] = *((int32_t *) (outhead+30));
           curabs1 = *((float *) (outhead+30));  *((int32_t *) (outhead+30)) = (int32_t) rint(curabs1*scalar1); 
           thdrvals[81] = *((int32_t *) (outhead+32));
           curabs1 = *((float *) (outhead+32));  *((int32_t *) (outhead+32)) = (int32_t) rint(curabs1*scalar1); 
        }

        /* compute precision scalars for source and receiver coordinates */
        {
           float curabs2;
           float maxabs2 = 0.0f;
           double scalar2;
           curabs2 = *((float *) (outhead+36));  if(curabs2 < 0.0f) curabs2 = -curabs2; 
                                                 if(curabs2 > maxabs2) maxabs2 = curabs2;
           curabs2 = *((float *) (outhead+38));  if(curabs2 < 0.0f) curabs2 = -curabs2; 
                                                 if(curabs2 > maxabs2) maxabs2 = curabs2;
           curabs2 = *((float *) (outhead+40));  if(curabs2 < 0.0f) curabs2 = -curabs2; 
                                                 if(curabs2 > maxabs2) maxabs2 = curabs2;
           curabs2 = *((float *) (outhead+42));  if(curabs2 < 0.0f) curabs2 = -curabs2; 
                                                 if(curabs2 > maxabs2) maxabs2 = curabs2;
           if(maxabs2 < 214748.3648f) {
              *((int16_t *) (outhead+35)) = -10000; scalar2 = 10000.0;
           } else if(maxabs2 < 2147483.648f) {
              *((int16_t *) (outhead+35)) = -1000; scalar2 = 1000.0;
           } else if(maxabs2 < 21474836.48f) {
              *((int16_t *) (outhead+35)) = -100; scalar2 = 100.0;
           } else if(maxabs2 < 214748364.8f) {
              *((int16_t *) (outhead+35)) = -10; scalar2 = 10.0;
           } else if(maxabs2 < 2147483648.0f) {
              *((int16_t *) (outhead+35)) = 1; scalar2 = 1.0;
           } else if(maxabs2 < 21474836480.0f) {
              *((int16_t *) (outhead+35)) = 10; scalar2 = 0.1;
           } else if(maxabs2 < 214748364800.0f) {
              *((int16_t *) (outhead+35)) = 100; scalar2 = 0.01;
           } else if(maxabs2 < 2147483648000.0f) {
              *((int16_t *) (outhead+35)) = 1000; scalar2 = 0.001;
           } else {
              *((int16_t *) (outhead+35)) = 10000; scalar2 = 0.0001;
           } 
           thdrvals[73] = *((int32_t *) (outhead+36));
           curabs2 = *((float *) (outhead+36));  *((int32_t *) (outhead+36)) = (int32_t) rint(curabs2*scalar2); 
           thdrvals[74] = *((int32_t *) (outhead+38));
           curabs2 = *((float *) (outhead+38));  *((int32_t *) (outhead+38)) = (int32_t) rint(curabs2*scalar2); 
           thdrvals[71] = *((int32_t *) (outhead+40));
           curabs2 = *((float *) (outhead+40));  *((int32_t *) (outhead+40)) = (int32_t) rint(curabs2*scalar2); 
           thdrvals[72] = *((int32_t *) (outhead+42));
           curabs2 = *((float *) (outhead+42));  *((int32_t *) (outhead+42)) = (int32_t) rint(curabs2*scalar2); 
        }

        /* as we're SEG-Y Rev 1, we should also employ bytes 215-216 to maximize temporal precision ... */
        /* right now, though, we leave it at millisecond accuracy */

	/* special case, execute on first pass only... */
	if (first == 1) {
	first = 0;
	  segyreelheader[1606] = numtrace;
	  segyreelheader[1608] = outhead[58];
	  segyreelheader[1609] = outhead[58];
	  segyreelheader[1610] = numsamples;
	  segyreelheader[1611] = numsamples;
          switch ((int) datatype) { /* double check this */
            case 1: segyreelheader[1612] = 2; break;
            case 2: segyreelheader[1612] = 3; break;
            case 3: segyreelheader[1612] = 3; break;
            case 4: segyreelheader[1612] = 5; break;
            case 5: segyreelheader[1612] = 5; break;
            default: break;
          }
          /* set SEG-Y revision number 1.0 */
          segyreelheader[1675] = 1*256+0;          

#ifdef notdef
          /* we really should copy out all File Descriptor Block strings into one or more */
          /* extended textual headers, but not doing that today.                          */

	  if (ImLittleEndian) /* swap only if we are on a little endian  machine */
	  {  
	    for (k = 1600; k < 1606; k += 2)
	       swaplong ((uint32_t *)&segyreelheader[k]);
	    for (k = 1606; k < 1630; k++)
	       swapshort((uint16_t *)&segyreelheader[k]);
	  }
	  fwrite (segyreelheader, 1, 3600, f2);  /*  create the segy headers */
#endif/*notdef*/
	} /* end first */

#ifdef notdef
	if (ImLittleEndian) { /* swap only if we are on a little endian  machine */
	    /* first swap longs */
	    for (k = 0; k < 7; k++)
		swaplong(outheadl+k);
	    for (k = 9; k < 17; k++)
	        swaplong(outheadl+k);
	    for (k = 18; k < 22; k++)
	        swaplong(outheadl+k);
	    /* now swap the shorts */ 
	    for (k = 14; k < 18; k++)
	       swapshort(outhead+k);
	    for (k = 34; k < 36; k++)
	       swapshort(outhead+k);
	    for (k = 44; k < 95; k++)
	       swapshort(outhead+k);
	}
#ifdef SEPOUTPUT/* { */
	if (120 != (k = fwrite (outhead, 2, 120, f2))) {      /* write header */
	    fprintf (stderr,"\nWrite failure during header write\n");
	    exit (-9);
	}
#endif/* } */

#endif/*notdef*/

        thdrvals[0] = outheadl[0]; /* tracl */
        thdrvals[1] = outheadl[1]; /* tracr */
        thdrvals[2] = outheadl[2]; /* fldr */
        thdrvals[3] = outheadl[3]; /* tracf */
        thdrvals[4] = outheadl[4]; /* ep */
        thdrvals[5] = outheadl[5]; /* cdp */
        thdrvals[6] = outheadl[6]; /* cdpt */
        thdrvals[7] = outhead[14]; /* trid */
        thdrvals[8] = outhead[15]; /* nvs */
        thdrvals[9] = outhead[16]; /* nhs */
        thdrvals[10] = outhead[17]; /* duse */
        thdrvals[11] = outheadl[9]; /* offset */
        thdrvals[12] = outheadl[10]; /* gelev */
        thdrvals[13] = outheadl[11]; /* selev */
        thdrvals[14] = outheadl[12]; /* sdepth */
        thdrvals[15] = outheadl[13]; /* gdel */
        thdrvals[16] = outheadl[14]; /* sdel */
        thdrvals[17] = outheadl[15]; /* swdep */
        thdrvals[18] = outheadl[16]; /* gwdep */
        thdrvals[19] = outhead[34]; /* scalel */
        thdrvals[20] = outhead[35]; /* scaleco */
        thdrvals[21] = outheadl[18]; /* sx */
        thdrvals[22] = outheadl[19]; /* sy */
        thdrvals[23] = outheadl[20]; /* gx */
        thdrvals[24] = outheadl[21]; /* gy */
        thdrvals[25] = outhead[44]; /* counit */
        thdrvals[26] = outhead[45]; /* welev */
        thdrvals[27] = outhead[46]; /* swelev */
        thdrvals[28] = outhead[47]; /* sut */
        thdrvals[29] = outhead[48]; /* gut */
        thdrvals[30] = outhead[49]; /* sstat */
        thdrvals[31] = outhead[50]; /* gstat */
        thdrvals[32] = outhead[51]; /* tstat */
        thdrvals[33] = outhead[52]; /* laga */
        thdrvals[34] = outhead[53]; /* lagb */
        thdrvals[35] = outhead[54]; /* delrt */
        thdrvals[36] = outhead[55]; /* muts */
        thdrvals[37] = outhead[56]; /* mute */
        thdrvals[38] = *((unsigned short *) (outhead+57)); /* ns */
        thdrvals[39] = *((unsigned short *) (outhead+58)); /* dt */
        thdrvals[40] = outhead[59]; /* gain */
        thdrvals[41] = outhead[60]; /* igc */
        thdrvals[42] = outhead[61]; /* igi */
        thdrvals[43] = outhead[62]; /* corr */
        thdrvals[44] = outhead[63]; /* sfs */
        thdrvals[45] = outhead[64]; /* sfe */
        thdrvals[46] = outhead[65]; /* slen */
        thdrvals[47] = outhead[66]; /* styp */
        thdrvals[48] = outhead[67]; /* stas */
        thdrvals[49] = outhead[68]; /* stae */
        thdrvals[50] = outhead[69]; /* tatyp */
        thdrvals[51] = outhead[70]; /* afilf */
        thdrvals[52] = outhead[71]; /* afils */
        thdrvals[53] = outhead[72]; /* nofilf */
        thdrvals[54] = outhead[73]; /* nofils */
        thdrvals[55] = outhead[74]; /* lcf */
        thdrvals[56] = outhead[75]; /* hcf */
        thdrvals[57] = outhead[76]; /* lcs */
        thdrvals[58] = outhead[77]; /* hcs */
        thdrvals[59] = outhead[78]; /* year */
        thdrvals[60] = outhead[79]; /* day */
        thdrvals[61] = outhead[80]; /* hour */
        thdrvals[62] = outhead[81]; /* minute */
        thdrvals[63] = outhead[82]; /* sec */
        thdrvals[64] = outhead[83]; /* timbas */
        thdrvals[65] = outhead[84]; /* trwf */
        thdrvals[66] = outhead[85]; /* grnors */
        thdrvals[67] = outhead[86]; /* grnofr */
        thdrvals[68] = outhead[87]; /* grnlof */
        thdrvals[69] = outhead[88]; /* gaps */
        thdrvals[70] = outhead[89]; /* otrav */
        thdrvals[82] = outhead[99]; /* module serial number */
        thdrvals[83] = outhead[100]; /* sensor calibration dB */
        thdrvals[84] = outhead[101]; /* sensor orientation Vert */
        thdrvals[85] = outhead[102]; /* sensor orientation Inline */
        thdrvals[86] = outhead[103]; /* sensor orientation Crossline */
        
#ifdef MATOUTPUT/* { */
        /* reposition to write next trace header */
        fseeko(fm,current_trace_header,SEEK_SET);

        k = 0;
        while(k < 71) {
            dtmp = thdrvals[k];
            if(ImLittleEndian) swapdouble(&dtmp);
            fwrite(&dtmp,1,sizeof(double),fm);
            ++k;
        }
        while(k < 82) {
            dtmp = *((float *)(thdrvals+k));
            if(ImLittleEndian) swapdouble(&dtmp);
            fwrite(&dtmp,1,sizeof(double),fm);
            ++k;
        }
        while(k < 83) {
            dtmp = thdrvals[k];
            if(ImLittleEndian) swapdouble(&dtmp);
            fwrite(&dtmp,1,sizeof(double),fm);
            ++k;
        }

        while(k < 87) {
            dtmp = *((float *)(thdrvals+k));
            if(ImLittleEndian) swapdouble(&dtmp);
            fwrite(&dtmp,1,sizeof(double),fm);
            ++k;
        }
        /* update trace header pointer into matlab file */
        current_trace_header = ftello(fm);
#endif/* } */

        if (ImLittleEndian) {
	        for (k = 0; k < sizeof(thdrvals)/sizeof(thdrvals[0]); k++)
		   swaplong ((uint32_t *) (&(thdrvals[k])));
        }
#ifdef SEPOUTPUT/* { */
	if (  ((size_t) ((sizeof(thdrvals)/sizeof(thdrvals[0])))) !=
           (k = fwrite(thdrvals, sizeof(thdrvals[0]), (size_t) (sizeof(thdrvals)/sizeof(thdrvals[0])), f3_at))
           ) {
	    fprintf (stderr,"Write failure during trace header write\n");
	    exit (-10);
	}
#endif/* } */

#ifdef MATOUTPUT/* { */
        fseeko(fm,current_trace_data,SEEK_SET);
#endif/* } */

	if (ImLittleEndian) {
            switch((int) datatype) {
            case 1:
	        for (k = 0; k < numsamples; k++) {
#ifdef MATOUTPUT/* { */
                   dtmp = iinbuf[k];
                   swapdouble(&dtmp);
                   fwrite(&dtmp,1,sizeof(double),fm);
#endif/* } */
		   swapshort (iinbuf+k);
                }
                break;
            case 2:
	        for (k = 0; k < numsamples; k++) {
#ifdef MATOUTPUT/* { */
                   dtmp = linbuf[k];
                   swapdouble(&dtmp);
                   fwrite(&dtmp,1,sizeof(double),fm);
#endif/* } */
		   swaplong (linbuf+k);
                }
                break;
            case 3:
	        for (k = 0; k < numsamples; k++) {
#ifdef MATOUTPUT/* { */
                   dtmp = outbuf[k];
                   swapdouble(&dtmp);
                   fwrite(&dtmp,1,sizeof(double),fm);
#endif/* } */
                   linbuf[k] = outbuf[k];
		   swaplong (linbuf+k);
                }
                break;
            case 4:
	        for (k = 0; k < numsamples; k++) {
                   if(finbuf[k] > 1.0e10 || finbuf[k] < -1.0e10)  {
			fprintf(stderr,"bad sample found\n");
                        abort();
                   }
#ifdef MATOUTPUT/* { */
                   dtmp = finbuf[k];
                   swapdouble(&dtmp);
                   fwrite(&dtmp,1,sizeof(double),fm);
#endif/* } */
		   swaplong (linbuf+k);
                }
                break;
            case 5:
	        for (k = 0; k < numsamples; k++) {
#ifdef MATOUTPUT/* { */
                   dtmp = dinbuf[k];
                   swapdouble(&dtmp);
                   fwrite(&dtmp,1,sizeof(double),fm);
#endif/* } */
                   finbuf[k] = (float) dinbuf[k];
                   swaplong (linbuf+k);
                }
                break;
            default:
                break;
            }
	} else {
            switch((int) datatype) {
            case 1:
	        for (k = 0; k < numsamples; k++) {
#ifdef MATOUTPUT/* { */
                   dtmp = iinbuf[k];
                   fwrite(&dtmp,1,sizeof(double),fm);
#endif/* } */
                }
                break;
            case 2:
	        for (k = 0; k < numsamples; k++) {
#ifdef MATOUTPUT/* { */
                   dtmp = linbuf[k];
                   fwrite(&dtmp,1,sizeof(double),fm);
#endif/* } */
                }
                break;
            case 3:
	        for (k = 0; k < numsamples; k++) {
#ifdef MATOUTPUT/* { */
                   dtmp = outbuf[k];
                   fwrite(&dtmp,1,sizeof(double),fm);
#endif/* } */
                }
                break;
            case 4:
	        for (k = 0; k < numsamples; k++) {
                   if(finbuf[k] > 1.0e10 || finbuf[k] < -1.0e10)  {
			fprintf(stderr,"bad sample found\n");
                        abort();
                   }
#ifdef MATOUTPUT/* { */
                   dtmp = finbuf[k];
                   fwrite(&dtmp,1,sizeof(double),fm);
#endif/* } */
                }
                break;
            case 5:
	        for (k = 0; k < numsamples; k++) {
#ifdef MATOUTPUT/* { */
                   dtmp = dinbuf[k];
                   fwrite(&dtmp,1,sizeof(double),fm);
#endif/* } */
                   finbuf[k] = (float) dinbuf[k];
                }
                break;
            default:
                break;
            }
        }
#ifdef MATOUTPUT/* { */
        current_trace_data = ftello(fm);
#endif/* } */
#ifdef SEPOUTPUT/* { */
	if (((size_t) numsamples) != (k = fwrite (cinbuf, (datatype == 1) ? 2 : 4, (size_t) numsamples, f3))) {
	    fprintf (stderr,"Write failure during trace write\n");
	    exit (-10);
	}
#endif/* } */

	}      /* end trace loop */

#ifdef MATOUTPUT/* { */
        /* update matlab length fields */

        curr_mat_loc = ftello(fm);
        ul = numtrace*sizeof(double)*numsamples+6*8;
        fseeko(fm,start_of_trace_data+4,SEEK_SET);
        if(ImLittleEndian) swaplong(&ul);       
        fwrite(&ul,1,sizeof(ul),fm); /* byte count in trace data array */
        ul = numsamples;
        fseeko(fm,start_of_trace_data+32,SEEK_SET);
        if(ImLittleEndian) swaplong(&ul);       
        fwrite(&ul,1,sizeof(ul),fm); /* number samples per trace */
        ul = numtrace*sizeof(double)*numsamples;
        fseeko(fm,start_of_trace_data+52,SEEK_SET);
        if(ImLittleEndian) swaplong(&ul);       
        fwrite(&ul,1,sizeof(ul),fm); /* number of bytes in trace array */

        ul = curr_mat_loc - start_of_seg2_structure - 8;
        fseeko(fm,start_of_seg2_structure+4,SEEK_SET);
        if(ImLittleEndian) swaplong(&ul);       
        fwrite(&ul,1,sizeof(ul),fm); /* byte count of seg2 structure */

        fseeko(fm,curr_mat_loc,SEEK_SET);
         
        fclose(fm);
#endif/* } */
#ifdef SEPOUTPUT/* { */
	fclose (f1);
#endif/* } */
	outhead[87] = 0;    /* reset last trace flag. */
	}        /* end kk loop */
#ifdef SEPOUTPUT/* { */
        /* put relevant parameters into output header before finishing */
        fprintf(f2,"\n\nin=%s\n",SEPdatafile);
        fprintf(f2,"hff=%s\n",SEPhdrfile_at);
        fprintf(f2,"esize=%u\n", (unsigned int) ((datatype == 1) ? 2 : 4));
        fprintf(f2,"data_format=%s\n",(datatype == 1) ? "xdr_short" : 
                                     ((datatype == 2) ? "xdr_int" :
                                     ((datatype == 3) ? "xdr_int" :
                                                        "xdr_float" )) );
        fprintf(f2,"label1=\"time(s)\" o1=0.0 d1=%g n1=%u\n",outhead[58]*0.000001, (unsigned int) numsamples);
        fprintf(f2,"label2=\"traceno\" o2=1.0 d2=1.0 n2=%u\n", (unsigned int) numtrace);
        fprintf(f2,"label3=\"recseqno\" o3=1.0 d3=1.0 n3=%u\n", (unsigned int) ssn-1);
        fclose(f2);
        fprintf(f2_at,"\n\nin=%s\n",SEPdatafile_at);
        fprintf(f2_at,"n1=87\n");
        fprintf(f2_at,"label2=\"traceno\" o2=1.0 d2=1.0 n2=%u\n", (unsigned int) numtrace);
        fprintf(f2_at,"hdrkey1=\"tracl\" hdrtype1=\"scalar_int\" hdrfmt1=\"xdr_int\"\n");
        fprintf(f2_at,"hdrkey2=\"tracr\" hdrtype2=\"scalar_int\" hdrfmt2=\"xdr_int\"\n");
        fprintf(f2_at,"hdrkey3=\"fldr\" hdrtype3=\"scalar_int\" hdrfmt3=\"xdr_int\"\n");
        fprintf(f2_at,"hdrkey4=\"tracf\" hdrtype4=\"scalar_int\" hdrfmt4=\"xdr_int\"\n");
        fprintf(f2_at,"hdrkey5=\"ep\" hdrtype5=\"scalar_int\" hdrfmt5=\"xdr_int\"\n");
        fprintf(f2_at,"hdrkey6=\"cdp\" hdrtype6=\"scalar_int\" hdrfmt6=\"xdr_int\"\n");
        fprintf(f2_at,"hdrkey7=\"cdpt\" hdrtype7=\"scalar_int\" hdrfmt7=\"xdr_int\"\n");
        fprintf(f2_at,"hdrkey8=\"trid\" hdrtype8=\"scalar_int\" hdrfmt8=\"xdr_int\"\n");
        fprintf(f2_at,"hdrkey9=\"nvs\" hdrtype9=\"scalar_int\" hdrfmt9=\"xdr_int\"\n");
        fprintf(f2_at,"hdrkey10=\"nhs\" hdrtype10=\"scalar_int\" hdrfmt10=\"xdr_int\"\n");
        fprintf(f2_at,"hdrkey11=\"duse\" hdrtype11=\"scalar_int\" hdrfmt11=\"xdr_int\"\n");
        fprintf(f2_at,"hdrkey12=\"offset\" hdrtype12=\"scalar_int\" hdrfmt12=\"xdr_int\"\n");
        fprintf(f2_at,"hdrkey13=\"gelev\" hdrtype13=\"scalar_int\" hdrfmt13=\"xdr_int\"\n");
        fprintf(f2_at,"hdrkey14=\"selev\" hdrtype14=\"scalar_int\" hdrfmt14=\"xdr_int\"\n");
        fprintf(f2_at,"hdrkey15=\"sdepth\" hdrtype15=\"scalar_int\" hdrfmt15=\"xdr_int\"\n");
        fprintf(f2_at,"hdrkey16=\"gdel\" hdrtype16=\"scalar_int\" hdrfmt16=\"xdr_int\"\n");
        fprintf(f2_at,"hdrkey17=\"sdel\" hdrtype17=\"scalar_int\" hdrfmt17=\"xdr_int\"\n");
        fprintf(f2_at,"hdrkey18=\"swdep\" hdrtype18=\"scalar_int\" hdrfmt18=\"xdr_int\"\n");
        fprintf(f2_at,"hdrkey19=\"gwdep\" hdrtype19=\"scalar_int\" hdrfmt19=\"xdr_int\"\n");
        fprintf(f2_at,"hdrkey20=\"scalel\" hdrtype20=\"scalar_int\" hdrfmt20=\"xdr_int\"\n");
        fprintf(f2_at,"hdrkey21=\"scaleco\" hdrtype21=\"scalar_int\" hdrfmt21=\"xdr_int\"\n");
        fprintf(f2_at,"hdrkey22=\"sx\" hdrtype22=\"scalar_int\" hdrfmt22=\"xdr_int\"\n");
        fprintf(f2_at,"hdrkey23=\"sy\" hdrtype23=\"scalar_int\" hdrfmt23=\"xdr_int\"\n");
        fprintf(f2_at,"hdrkey24=\"gx\" hdrtype24=\"scalar_int\" hdrfmt24=\"xdr_int\"\n");
        fprintf(f2_at,"hdrkey25=\"gx\" hdrtype25=\"scalar_int\" hdrfmt25=\"xdr_int\"\n");
        fprintf(f2_at,"hdrkey26=\"counit\" hdrtype26=\"scalar_int\" hdrfmt26=\"xdr_int\"\n");
        fprintf(f2_at,"hdrkey27=\"welev\" hdrtype27=\"scalar_int\" hdrfmt27=\"xdr_int\"\n");
        fprintf(f2_at,"hdrkey28=\"swelev\" hdrtype28=\"scalar_int\" hdrfmt28=\"xdr_int\"\n");
        fprintf(f2_at,"hdrkey29=\"sut\" hdrtype29=\"scalar_int\" hdrfmt29=\"xdr_int\"\n");
        fprintf(f2_at,"hdrkey30=\"gut\" hdrtype30=\"scalar_int\" hdrfmt30=\"xdr_int\"\n");
        fprintf(f2_at,"hdrkey31=\"sstat\" hdrtype31=\"scalar_int\" hdrfmt31=\"xdr_int\"\n");
        fprintf(f2_at,"hdrkey32=\"gstat\" hdrtype32=\"scalar_int\" hdrfmt32=\"xdr_int\"\n");
        fprintf(f2_at,"hdrkey33=\"tstat\" hdrtype33=\"scalar_int\" hdrfmt33=\"xdr_int\"\n");
        fprintf(f2_at,"hdrkey34=\"laga\" hdrtype34=\"scalar_int\" hdrfmt34=\"xdr_int\"\n");
        fprintf(f2_at,"hdrkey35=\"lagb\" hdrtype35=\"scalar_int\" hdrfmt35=\"xdr_int\"\n");
        fprintf(f2_at,"hdrkey36=\"delrt\" hdrtype36=\"scalar_int\" hdrfmt36=\"xdr_int\"\n");
        fprintf(f2_at,"hdrkey37=\"muts\" hdrtype37=\"scalar_int\" hdrfmt37=\"xdr_int\"\n");
        fprintf(f2_at,"hdrkey38=\"mute\" hdrtype38=\"scalar_int\" hdrfmt38=\"xdr_int\"\n");
        fprintf(f2_at,"hdrkey39=\"ns\" hdrtype39=\"scalar_int\" hdrfmt39=\"xdr_int\"\n");
        fprintf(f2_at,"hdrkey40=\"dt\" hdrtype40=\"scalar_int\" hdrfmt40=\"xdr_int\"\n");
        fprintf(f2_at,"hdrkey41=\"gain\" hdrtype41=\"scalar_int\" hdrfmt41=\"xdr_int\"\n");
        fprintf(f2_at,"hdrkey42=\"igc\" hdrtype42=\"scalar_int\" hdrfmt42=\"xdr_int\"\n");
        fprintf(f2_at,"hdrkey43=\"igi\" hdrtype43=\"scalar_int\" hdrfmt43=\"xdr_int\"\n");
        fprintf(f2_at,"hdrkey44=\"corr\" hdrtype44=\"scalar_int\" hdrfmt44=\"xdr_int\"\n");
        fprintf(f2_at,"hdrkey45=\"sfs\" hdrtype45=\"scalar_int\" hdrfmt45=\"xdr_int\"\n");
        fprintf(f2_at,"hdrkey46=\"sfe\" hdrtype46=\"scalar_int\" hdrfmt46=\"xdr_int\"\n");
        fprintf(f2_at,"hdrkey47=\"slen\" hdrtype47=\"scalar_int\" hdrfmt47=\"xdr_int\"\n");
        fprintf(f2_at,"hdrkey48=\"styp\" hdrtype48=\"scalar_int\" hdrfmt48=\"xdr_int\"\n");
        fprintf(f2_at,"hdrkey49=\"stas\" hdrtype49=\"scalar_int\" hdrfmt49=\"xdr_int\"\n");
        fprintf(f2_at,"hdrkey50=\"stae\" hdrtype50=\"scalar_int\" hdrfmt50=\"xdr_int\"\n");
        fprintf(f2_at,"hdrkey51=\"tatyp\" hdrtype51=\"scalar_int\" hdrfmt51=\"xdr_int\"\n");
        fprintf(f2_at,"hdrkey52=\"afilf\" hdrtype52=\"scalar_int\" hdrfmt52=\"xdr_int\"\n");
        fprintf(f2_at,"hdrkey53=\"afils\" hdrtype53=\"scalar_int\" hdrfmt53=\"xdr_int\"\n");
        fprintf(f2_at,"hdrkey54=\"nofilf\" hdrtype54=\"scalar_int\" hdrfmt54=\"xdr_int\"\n");
        fprintf(f2_at,"hdrkey55=\"nofils\" hdrtype55=\"scalar_int\" hdrfmt55=\"xdr_int\"\n");
        fprintf(f2_at,"hdrkey56=\"lcf\" hdrtype56=\"scalar_int\" hdrfmt56=\"xdr_int\"\n");
        fprintf(f2_at,"hdrkey57=\"hcf\" hdrtype57=\"scalar_int\" hdrfmt57=\"xdr_int\"\n");
        fprintf(f2_at,"hdrkey58=\"lcs\" hdrtype58=\"scalar_int\" hdrfmt58=\"xdr_int\"\n");
        fprintf(f2_at,"hdrkey59=\"hcs\" hdrtype59=\"scalar_int\" hdrfmt59=\"xdr_int\"\n");
        fprintf(f2_at,"hdrkey60=\"year\" hdrtype60=\"scalar_int\" hdrfmt60=\"xdr_int\"\n");
        fprintf(f2_at,"hdrkey61=\"day\" hdrtype61=\"scalar_int\" hdrfmt61=\"xdr_int\"\n");
        fprintf(f2_at,"hdrkey62=\"hour\" hdrtype62=\"scalar_int\" hdrfmt62=\"xdr_int\"\n");
        fprintf(f2_at,"hdrkey63=\"minute\" hdrtype63=\"scalar_int\" hdrfmt63=\"xdr_int\"\n");
        fprintf(f2_at,"hdrkey64=\"sec\" hdrtype64=\"scalar_int\" hdrfmt64=\"xdr_int\"\n");
        fprintf(f2_at,"hdrkey65=\"timbas\" hdrtype65=\"scalar_int\" hdrfmt65=\"xdr_int\"\n");
        fprintf(f2_at,"hdrkey66=\"trwf\" hdrtype66=\"scalar_int\" hdrfmt66=\"xdr_int\"\n");
        fprintf(f2_at,"hdrkey67=\"grnors\" hdrtype67=\"scalar_int\" hdrfmt67=\"xdr_int\"\n");
        fprintf(f2_at,"hdrkey68=\"grnofr\" hdrtype68=\"scalar_int\" hdrfmt68=\"xdr_int\"\n");
        fprintf(f2_at,"hdrkey69=\"grnlof\" hdrtype69=\"scalar_int\" hdrfmt69=\"xdr_int\"\n");
        fprintf(f2_at,"hdrkey70=\"gaps\" hdrtype70=\"scalar_int\" hdrfmt70=\"xdr_int\"\n");
        fprintf(f2_at,"hdrkey71=\"otrav\" hdrtype71=\"scalar_int\" hdrfmt71=\"xdr_int\"\n");
        fprintf(f2_at,"hdrkey72=\"gxflt\" hdrtype72=\"scalar_float\" hdrfmt72=\"xdr_float\"\n");
        fprintf(f2_at,"hdrkey73=\"gyflt\" hdrtype73=\"scalar_float\" hdrfmt73=\"xdr_float\"\n");
        fprintf(f2_at,"hdrkey74=\"sxflt\" hdrtype74=\"scalar_float\" hdrfmt74=\"xdr_float\"\n");
        fprintf(f2_at,"hdrkey75=\"syflt\" hdrtype75=\"scalar_float\" hdrfmt75=\"xdr_float\"\n");
        fprintf(f2_at,"hdrkey76=\"gelevflt\" hdrtype76=\"scalar_float\" hdrfmt76=\"xdr_float\"\n");
        fprintf(f2_at,"hdrkey77=\"selevflt\" hdrtype77=\"scalar_float\" hdrfmt77=\"xdr_float\"\n");
        fprintf(f2_at,"hdrkey78=\"sdepthflt\" hdrtype78=\"scalar_float\" hdrfmt78=\"xdr_float\"\n");
        fprintf(f2_at,"hdrkey79=\"gdelflt\" hdrtype79=\"scalar_float\" hdrfmt79=\"xdr_float\"\n");
        fprintf(f2_at,"hdrkey80=\"sdelflt\" hdrtype80=\"scalar_float\" hdrfmt80=\"xdr_float\"\n");
        fprintf(f2_at,"hdrkey81=\"swdepflt\" hdrtype81=\"scalar_float\" hdrfmt81=\"xdr_float\"\n");
        fprintf(f2_at,"hdrkey82=\"gwdepflt\" hdrtype82=\"scalar_float\" hdrfmt82=\"xdr_float\"\n");
        fprintf(f2_at,"hdrkey83=\"modsernum\" hdrtype83=\"scalar_int\" hdrfmt83=\"xdr_int\"\n");
        fprintf(f2_at,"hdrkey84=\"senscalibdb\" hdrtype84=\"scalar_float\" hdrfmt84=\"xdr_float\"\n");
        fprintf(f2_at,"hdrkey85=\"sensorientvertical\" hdrtype85=\"scalar_float\" hdrfmt85=\"xdr_float\"\n");
        fprintf(f2_at,"hdrkey86=\"sensorientinline\" hdrtype86=\"scalar_float\" hdrfmt86=\"xdr_float\"\n");
        fprintf(f2_at,"hdrkey87=\"sensorientcrossline\" hdrtype87=\"scalar_float\" hdrfmt87=\"xdr_float\"\n");
        fclose(f2_at);
	fclose(f3);
	fclose(f3_at);
#endif/* } */
	return 0;
}        /* end main */